# Release 2.2 — Approval / Work Log Separation

## Fixes
- Added a dedicated `POST /api/tickets/{id}/approve_plan/` action.
- Approve & Plan does not create, read, or update work logs as part of the approval transaction.
- Work logging is only available after delivery has started (`IN_PROGRESS`, `ON_HOLD`, or `RESOLVED`).
- Work logs are restricted to the assigned resource (or superadmin).
- The UI explicitly explains that approval/planning is independent of work logs.

## Deployment
No schema migration is required for this release.
