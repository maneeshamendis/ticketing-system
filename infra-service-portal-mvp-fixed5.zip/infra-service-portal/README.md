# Infrastructure Service Management Portal

A self-hosted internal ITSM portal for Infrastructure teams.

## MVP included

- Requester dashboard and ticket submission
- Ticket number generation (`INFRA-YYYY-NNNNNN`)
- Created -> Manager Review -> Approved -> Assigned -> In Progress -> On Hold -> Resolved -> Closed workflow
- Suggested requester priority vs manager-controlled actual priority
- Budget, Security Sign-Off, BOQ, PMO allocation and BAU fields
- `.xlsx` / `.xlsm` BOQ validation and attachment storage
- Ticket assignment and self-claim for agents
- Delivery date and planned hours
- Subtasks with assignees and due dates
- Work logging
- Resource allocation/calendar API foundation
- Audit trail and comments
- Manager dashboard metrics
- Django admin for controlled administration
- OIDC/AD SSO-ready user model and configuration hooks
- Docker Compose with isolated host ports (`18080` web, `18081` API)

## Architecture

React/Vite frontend -> Django REST API -> PostgreSQL / Redis / Celery

The application is designed around OIDC for future AD SSO. A production SSO deployment should use Microsoft Entra ID or Keycloak federated to Active Directory rather than storing AD passwords in this application.

## Run

1. Copy `.env.example` to `.env` and change `DJANGO_SECRET_KEY` and database password.
2. Start the stack:

```bash
docker compose up -d --build
```

3. Create the initial superadmin:

```bash
docker compose exec api python manage.py createsuperuser
```

4. Open `http://SERVER:18080`.
5. Django admin: `http://SERVER:18081/admin/`

The frontend API proxy expects the API service on the internal Docker network. If you later expose the portal via an existing host reverse proxy, proxy `/api/` and `/admin/` to port `18081` or proxy the frontend to `18080`.

## First production hardening steps

- Put the frontend behind HTTPS.
- Set a strong secret and database password.
- Restrict database/Redis exposure to localhost/internal Docker networks.
- Enable ClamAV profile and wire attachment scanning before external use.
- Configure OIDC with Entra ID or Keycloak + AD.
- Set business hours, public holidays and SLA policies.
- Configure backups for PostgreSQL and media.

### Seed initial configuration

```bash
docker compose exec api python manage.py seed_data
```

For a local-only demo, you can also create demo accounts:

```bash
docker compose exec api python manage.py seed_data --demo-user
```

Demo credentials are `admin/admin` and `engineer/engineer`. **Do not use these credentials in a real environment.**

### Important schema note for this first MVP

The initial container startup uses Django's `migrate --run-syncdb` so the un-migrated `tickets` app can bootstrap its tables without requiring the build machine to have Django installed. After the first deployment, create normal Django migrations before making schema changes:

```bash
docker compose exec api python manage.py makemigrations tickets
docker compose exec api python manage.py migrate
```

## First deployment database initialization

This project uses Django migrations. On the first deployment of this corrected MVP, remove the MVP database volume created by earlier broken builds before starting the stack again:

```bash
docker compose down -v
docker compose up -d --build
```

Do not use `migrate --run-syncdb` with this project.
