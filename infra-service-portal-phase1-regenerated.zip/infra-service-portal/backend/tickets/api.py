from datetime import timedelta
from decimal import Decimal
from django.contrib.auth import get_user_model
from django.db.models import Q, Sum
from django.utils import timezone
from rest_framework import status, viewsets, permissions
from rest_framework.decorators import action
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Team, Category, Ticket, TicketComment, Attachment, SubTask, WorkLog, ResourceAllocation, Approval, AuditLog
from .serializers import (
    UserSerializer, TeamSerializer, CategorySerializer, TicketSerializer, TicketCommentSerializer,
    AttachmentSerializer, SubTaskSerializer, WorkLogSerializer, ResourceAllocationSerializer,
)

User = get_user_model()

class RolePermission(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated)

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all().order_by("first_name", "last_name", "username")
    serializer_class = UserSerializer
    permission_classes = [RolePermission]
    filterset_fields = ["role", "department", "is_active"]
    search_fields = ["username", "first_name", "last_name", "email", "ad_username"]

    def perform_update(self, serializer):
        # Only superadmins can change roles and SSO identity fields.
        if not (self.request.user.is_superuser or self.request.user.role == User.Roles.SUPERADMIN):
            blocked = {"role", "ad_username", "oidc_subject", "is_ssm_managed"}
            if blocked & set(serializer.validated_data.keys()):
                raise permissions.PermissionDenied("Only superadmins can manage role/SSO identity fields.")
        serializer.save()

class TeamViewSet(viewsets.ModelViewSet):
    queryset = Team.objects.prefetch_related("members").all()
    serializer_class = TeamSerializer
    permission_classes = [RolePermission]
    search_fields = ["name", "code"]

class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [RolePermission]
    search_fields = ["name", "code"]

class TicketViewSet(viewsets.ModelViewSet):
    queryset = Ticket.objects.select_related("requester", "assigned_to", "assigned_team", "category").prefetch_related("comments", "attachments", "subtasks", "worklogs", "approvals", "audit_logs")
    serializer_class = TicketSerializer
    permission_classes = [RolePermission]
    filterset_fields = ["status", "actual_priority", "requester_priority", "ticket_type", "category", "assigned_to", "assigned_team", "is_bau"]
    search_fields = ["ticket_number", "title", "description"]
    ordering_fields = ["created_at", "updated_at", "delivery_date", "actual_priority"]

    OPEN_STATUSES = {
        Ticket.Status.CREATED, Ticket.Status.MANAGER_REVIEW, Ticket.Status.NEEDS_INFORMATION,
        Ticket.Status.APPROVED, Ticket.Status.ASSIGNED, Ticket.Status.IN_PROGRESS, Ticket.Status.ON_HOLD,
    }
    MANAGER_ROLES = {User.Roles.MANAGER, User.Roles.SUPERADMIN}
    WORK_ROLES = {User.Roles.INFRA_AGENT, User.Roles.MANAGER, User.Roles.SUPERADMIN}

    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user
        if user.role == User.Roles.REQUESTER and not user.is_superuser:
            qs = qs.filter(requester=user)
        return qs

    def _is_manager(self, user):
        return user.is_superuser or user.role in self.MANAGER_ROLES

    def _can_work(self, user):
        return user.is_superuser or user.role in self.WORK_ROLES

    def _audit(self, ticket, action, before=None, after=None, actor=None):
        AuditLog.objects.create(ticket=ticket, actor=actor, action=action, before=before or {}, after=after or {})

    def perform_create(self, serializer):
        ticket = serializer.save(
            requester=self.request.user,
            actual_priority=serializer.validated_data.get("requester_priority", Ticket.Priority.P3),
            status=Ticket.Status.CREATED,
        )
        # Default new requests to the Infrastructure team when the seed data exists.
        infra_team = Team.objects.filter(code="INFRA", is_active=True).first()
        if infra_team:
            ticket.assigned_team = infra_team
            ticket.save(update_fields=["assigned_team", "updated_at"])
        self._audit(
            ticket,
            "TICKET_CREATED",
            after={"status": ticket.status, "requester_priority": ticket.requester_priority},
            actor=self.request.user,
        )

    def perform_update(self, serializer):
        user = self.request.user
        if user.role == User.Roles.REQUESTER and not user.is_superuser:
            allowed = {"title", "description", "requested_delivery_date", "requester_priority", "is_bau"}
            incoming = set(serializer.validated_data.keys())
            blocked = incoming - allowed
            if blocked:
                raise permissions.PermissionDenied(
                    "Requesters cannot modify manager-controlled fields: " + ", ".join(sorted(blocked))
                )
        ticket = serializer.instance
        before = {
            "status": ticket.status,
            "actual_priority": ticket.actual_priority,
            "assigned_to": ticket.assigned_to_id,
            "delivery_date": str(ticket.delivery_date) if ticket.delivery_date else None,
            "planned_hours": float(ticket.planned_hours) if ticket.planned_hours is not None else None,
        }
        ticket = serializer.save()
        after = {
            "status": ticket.status,
            "actual_priority": ticket.actual_priority,
            "assigned_to": ticket.assigned_to_id,
            "delivery_date": str(ticket.delivery_date) if ticket.delivery_date else None,
            "planned_hours": float(ticket.planned_hours) if ticket.planned_hours is not None else None,
        }
        self._audit(ticket, "TICKET_UPDATED", before, after, user)

    @action(detail=True, methods=["post"])
    def start_review(self, request, pk=None):
        if not self._is_manager(request.user):
            return Response({"detail": "Manager access required."}, status=403)
        ticket = self.get_object()
        if ticket.status not in {Ticket.Status.CREATED, Ticket.Status.NEEDS_INFORMATION}:
            return Response({"detail": "Ticket is not waiting to enter manager review."}, status=409)
        old = {"status": ticket.status}
        ticket.status = Ticket.Status.MANAGER_REVIEW
        ticket.save(update_fields=["status", "updated_at"])
        self._audit(ticket, "MANAGER_REVIEW_STARTED", old, {"status": ticket.status}, request.user)
        return Response(self.get_serializer(ticket).data)

    @action(detail=True, methods=["post"])
    def review(self, request, pk=None):
        if not self._is_manager(request.user):
            return Response({"detail": "Manager access required."}, status=403)
        ticket = self.get_object()
        if ticket.status != Ticket.Status.MANAGER_REVIEW:
            return Response({"detail": "Ticket must be in Manager Review before a decision can be made."}, status=409)

        decision = str(request.data.get("decision", "APPROVE")).upper()
        if decision not in {"APPROVE", "REJECT", "NEEDS_INFORMATION"}:
            return Response({"detail": "Decision must be APPROVE, REJECT or NEEDS_INFORMATION."}, status=400)

        actual_priority = request.data.get("actual_priority") or ticket.actual_priority
        if actual_priority not in dict(Ticket.Priority.choices):
            return Response({"detail": "Invalid actual priority."}, status=400)

        delivery_date = request.data.get("delivery_date") or None
        planned_start_date = request.data.get("planned_start_date") or None
        planned_hours = request.data.get("planned_hours")
        assigned_to = request.data.get("assigned_to") or None
        assigned_team = request.data.get("assigned_team") or ticket.assigned_team_id
        note = str(request.data.get("note", "")).strip()

        if decision == "APPROVE" and not delivery_date:
            return Response({"detail": "Delivery date is required when approving a ticket."}, status=400)
        if decision == "APPROVE" and planned_hours in (None, "", "0", 0):
            return Response({"detail": "Planned hours are required when approving a ticket."}, status=400)

        if assigned_to:
            assignee = User.objects.filter(pk=assigned_to, is_active=True).first()
            if not assignee:
                return Response({"detail": "Selected assignee does not exist or is inactive."}, status=400)
            if assignee.role not in self.WORK_ROLES:
                return Response({"detail": "Tickets can only be assigned to Infrastructure team members."}, status=400)

        old = {
            "status": ticket.status,
            "actual_priority": ticket.actual_priority,
            "assigned_to": ticket.assigned_to_id,
            "delivery_date": str(ticket.delivery_date) if ticket.delivery_date else None,
            "planned_hours": float(ticket.planned_hours) if ticket.planned_hours is not None else None,
        }
        ticket.actual_priority = actual_priority
        ticket.delivery_date = delivery_date
        ticket.planned_start_date = planned_start_date
        ticket.planned_hours = planned_hours
        ticket.assigned_to_id = assigned_to
        ticket.assigned_team_id = assigned_team
        if decision == "APPROVE":
            ticket.status = Ticket.Status.ASSIGNED if assigned_to else Ticket.Status.APPROVED
        elif decision == "REJECT":
            ticket.status = Ticket.Status.REJECTED
        else:
            ticket.status = Ticket.Status.NEEDS_INFORMATION
        ticket.save()
        if note:
            visibility = TicketComment.Visibility.PUBLIC if decision == "NEEDS_INFORMATION" else TicketComment.Visibility.INTERNAL
            TicketComment.objects.create(ticket=ticket, author=request.user, body=note, visibility=visibility)
        self._audit(
            ticket,
            f"MANAGER_REVIEW_{decision}",
            old,
            {
                "status": ticket.status,
                "actual_priority": ticket.actual_priority,
                "assigned_to": ticket.assigned_to_id,
                "delivery_date": str(ticket.delivery_date) if ticket.delivery_date else None,
                "planned_hours": float(ticket.planned_hours) if ticket.planned_hours is not None else None,
            },
            request.user,
        )
        return Response(self.get_serializer(ticket).data)

    @action(detail=True, methods=["post"])
    def assign(self, request, pk=None):
        if not self._is_manager(request.user):
            return Response({"detail": "Manager access required."}, status=403)
        ticket = self.get_object()
        if ticket.status not in {Ticket.Status.APPROVED, Ticket.Status.ASSIGNED, Ticket.Status.MANAGER_REVIEW}:
            return Response({"detail": "Ticket cannot be assigned from its current state."}, status=409)
        assignee_id = request.data.get("assigned_to") or None
        team_id = request.data.get("assigned_team") or ticket.assigned_team_id
        if not assignee_id and not team_id:
            return Response({"detail": "Provide an infrastructure resource or team."}, status=400)
        assignee = None
        if assignee_id:
            assignee = User.objects.filter(pk=assignee_id, is_active=True).first()
            if not assignee:
                return Response({"detail": "Selected assignee does not exist or is inactive."}, status=400)
            if assignee.role not in self.WORK_ROLES:
                return Response({"detail": "Selected user is not an Infrastructure team member."}, status=400)
        old = {"assigned_to": ticket.assigned_to_id, "assigned_team": ticket.assigned_team_id, "status": ticket.status}
        ticket.assigned_to = assignee
        ticket.assigned_team_id = team_id
        ticket.status = Ticket.Status.ASSIGNED
        ticket.save()
        self._audit(ticket, "TICKET_ASSIGNED", old, {"assigned_to": ticket.assigned_to_id, "assigned_team": ticket.assigned_team_id, "status": ticket.status}, request.user)
        return Response(self.get_serializer(ticket).data)

    @action(detail=True, methods=["post"])
    def claim(self, request, pk=None):
        if not self._can_work(request.user):
            return Response({"detail": "Infrastructure agent access required."}, status=403)
        ticket = self.get_object()
        if ticket.status not in {Ticket.Status.APPROVED, Ticket.Status.ASSIGNED}:
            return Response({"detail": "Only approved/unassigned work can be claimed."}, status=409)
        if ticket.assigned_to_id:
            return Response({"detail": "Ticket is already assigned."}, status=409)
        if ticket.assigned_team_id and not ticket.assigned_team.members.filter(pk=request.user.pk).exists() and request.user.role not in self.MANAGER_ROLES:
            return Response({"detail": "You are not a member of the assigned team."}, status=403)
        old = {"assigned_to": None, "status": ticket.status}
        ticket.assigned_to = request.user
        ticket.status = Ticket.Status.ASSIGNED
        ticket.save()
        self._audit(ticket, "TICKET_CLAIMED", old, {"assigned_to": request.user.id, "status": ticket.status}, request.user)
        return Response(self.get_serializer(ticket).data)

    @action(detail=True, methods=["post"])
    def transition(self, request, pk=None):
        ticket = self.get_object()
        new_status = request.data.get("status")
        actor = request.user
        allowed_statuses = {value for value, _ in Ticket.Status.choices}
        if new_status not in allowed_statuses:
            return Response({"detail": "Invalid status."}, status=400)

        # Deliberately narrow the transition matrix. This prevents users from jumping directly to Closed/Resolved.
        matrix = {
            Ticket.Status.APPROVED: {Ticket.Status.ASSIGNED, Ticket.Status.CANCELLED},
            Ticket.Status.ASSIGNED: {Ticket.Status.IN_PROGRESS, Ticket.Status.CANCELLED},
            Ticket.Status.IN_PROGRESS: {Ticket.Status.ON_HOLD, Ticket.Status.RESOLVED, Ticket.Status.CANCELLED},
            Ticket.Status.ON_HOLD: {Ticket.Status.IN_PROGRESS, Ticket.Status.CANCELLED},
            Ticket.Status.RESOLVED: {Ticket.Status.CLOSED},
            Ticket.Status.NEEDS_INFORMATION: {Ticket.Status.MANAGER_REVIEW},
        }
        if new_status not in matrix.get(ticket.status, set()):
            return Response({"detail": f"Cannot move {ticket.get_status_display()} to {dict(Ticket.Status.choices).get(new_status, new_status)}."}, status=409)

        if actor.role == User.Roles.REQUESTER and not actor.is_superuser:
            if new_status not in {Ticket.Status.CANCELLED, Ticket.Status.MANAGER_REVIEW}:
                return Response({"detail": "Requesters can only cancel or resubmit tickets awaiting information."}, status=403)
            if new_status == Ticket.Status.MANAGER_REVIEW and ticket.status != Ticket.Status.NEEDS_INFORMATION:
                return Response({"detail": "Only tickets awaiting information can be resubmitted for review."}, status=403)
        elif not self._is_manager(actor):
            if new_status in {Ticket.Status.CANCELLED}:
                return Response({"detail": "Only the requester or a manager can cancel a ticket."}, status=403)
            if not self._can_work(actor):
                return Response({"detail": "Infrastructure access required."}, status=403)
            if ticket.assigned_to_id and ticket.assigned_to_id != actor.id:
                return Response({"detail": "Only the assigned resource can progress this ticket."}, status=403)
            if new_status == Ticket.Status.CLOSED:
                return Response({"detail": "Only managers can close resolved tickets."}, status=403)

        old = {"status": ticket.status}
        ticket.status = new_status
        if new_status == Ticket.Status.CLOSED:
            ticket.closed_at = timezone.now()
        ticket.save()
        self._audit(ticket, "STATUS_CHANGED", old, {"status": new_status}, actor)
        return Response(self.get_serializer(ticket).data)

    @action(detail=True, methods=["post"])
    def comment(self, request, pk=None):
        ticket = self.get_object()
        visibility = request.data.get("visibility", "PUBLIC")
        if visibility == "INTERNAL" and request.user.role == User.Roles.REQUESTER:
            return Response({"detail": "Requesters cannot add internal comments."}, status=403)
        body = str(request.data.get("body", "")).strip()
        if not body:
            return Response({"detail": "Comment cannot be empty."}, status=400)
        comment = TicketComment.objects.create(ticket=ticket, author=request.user, body=body, visibility=visibility)
        self._audit(ticket, "COMMENT_ADDED", {}, {"comment_id": comment.id, "visibility": visibility}, request.user)
        return Response(TicketCommentSerializer(comment).data, status=201)

class SubTaskViewSet(viewsets.ModelViewSet):
    queryset = SubTask.objects.select_related("ticket", "assignee", "created_by")
    serializer_class = SubTaskSerializer
    permission_classes = [RolePermission]
    filterset_fields = ["ticket", "assignee", "status", "priority"]
    search_fields = ["title", "description"]

    def perform_create(self, serializer):
        ticket_id = self.request.data.get("ticket")
        if self.request.user.role == User.Roles.REQUESTER:
            ticket = Ticket.objects.get(id=ticket_id)
            if ticket.requester_id != self.request.user.id:
                raise permissions.PermissionDenied("You can only create tasks for your own tickets.")
        serializer.save(created_by=self.request.user)

class CommentViewSet(viewsets.ModelViewSet):
    queryset = TicketComment.objects.select_related("ticket", "author")
    def get_queryset(self):
        qs = super().get_queryset()
        if self.request.user.role == User.Roles.REQUESTER and not self.request.user.is_superuser:
            qs = qs.filter(ticket__requester=self.request.user, visibility=TicketComment.Visibility.PUBLIC)
        return qs
    serializer_class = TicketCommentSerializer
    permission_classes = [RolePermission]
    filterset_fields = ["ticket", "visibility"]

    def perform_create(self, serializer):
        if serializer.validated_data.get("visibility") == TicketComment.Visibility.INTERNAL and self.request.user.role == User.Roles.REQUESTER:
            raise permissions.PermissionDenied("Requesters cannot create internal comments.")
        serializer.save(author=self.request.user)

class AttachmentViewSet(viewsets.ModelViewSet):
    queryset = Attachment.objects.select_related("ticket", "uploaded_by")
    serializer_class = AttachmentSerializer
    permission_classes = [RolePermission]
    parser_classes = [MultiPartParser, FormParser]
    filterset_fields = ["ticket"]

    def perform_create(self, serializer):
        ticket_id = self.request.data.get("ticket")
        ticket = Ticket.objects.get(id=ticket_id)
        if self.request.user.role == User.Roles.REQUESTER and ticket.requester_id != self.request.user.id:
            raise permissions.PermissionDenied("You can only attach files to your own tickets.")
        uploaded = self.request.FILES.get("file")
        name = uploaded.name if uploaded else ""
        if ticket.boq_document and not name.lower().endswith((".xlsx", ".xlsm")):
            # Other files are fine; this only blocks a non-Excel file where the BOQ field is explicitly selected for its first upload.
            pass
        serializer.save(uploaded_by=self.request.user, original_name=name, content_type=getattr(uploaded, "content_type", ""), size_bytes=getattr(uploaded, "size", 0))

class WorkLogViewSet(viewsets.ModelViewSet):
    queryset = WorkLog.objects.select_related("ticket", "user")
    serializer_class = WorkLogSerializer
    permission_classes = [RolePermission]
    filterset_fields = ["ticket", "user", "work_date"]

    def perform_create(self, serializer):
        log = serializer.save(user=self.request.user)
        total = WorkLog.objects.filter(ticket_id=log.ticket_id).aggregate(v=Sum("hours"))["v"] or Decimal("0")
        Ticket.objects.filter(id=log.ticket_id).update(actual_hours=total)

class ResourceAllocationViewSet(viewsets.ModelViewSet):
    queryset = ResourceAllocation.objects.select_related("user", "ticket", "allocated_by")
    def get_queryset(self):
        qs = super().get_queryset()
        if self.request.user.role == User.Roles.REQUESTER and not self.request.user.is_superuser:
            qs = qs.filter(user=self.request.user)
        return qs
    serializer_class = ResourceAllocationSerializer
    permission_classes = [RolePermission]
    filterset_fields = ["user", "ticket", "allocation_date"]

    def perform_create(self, serializer):
        if not (self.request.user.is_superuser or self.request.user.role in {User.Roles.MANAGER, User.Roles.SUPERADMIN}):
            raise permissions.PermissionDenied("Only managers can allocate capacity.")
        serializer.save(allocated_by=self.request.user)

class MeView(APIView):
    permission_classes = [RolePermission]
    def get(self, request):
        from .serializers import UserBriefSerializer
        return Response(UserBriefSerializer(request.user).data)

class DashboardView(APIView):
    permission_classes = [RolePermission]
    def get(self, request):
        qs = Ticket.objects.all()
        if request.user.role == User.Roles.REQUESTER and not request.user.is_superuser:
            qs = qs.filter(requester=request.user)
        today = timezone.localdate()
        week = today + timedelta(days=7)
        open_statuses = [Ticket.Status.CREATED, Ticket.Status.MANAGER_REVIEW, Ticket.Status.NEEDS_INFORMATION, Ticket.Status.APPROVED, Ticket.Status.ASSIGNED, Ticket.Status.IN_PROGRESS, Ticket.Status.ON_HOLD]
        total_open = qs.filter(status__in=open_statuses).count()
        awaiting_review = qs.filter(status=Ticket.Status.MANAGER_REVIEW).count()
        in_progress = qs.filter(status=Ticket.Status.IN_PROGRESS).count()
        overdue = qs.filter(delivery_date__lt=today, status__in=open_statuses).count()
        due_this_week = qs.filter(delivery_date__gte=today, delivery_date__lte=week, status__in=open_statuses).count()
        resolved = qs.filter(status=Ticket.Status.RESOLVED).count()
        planned = qs.aggregate(v=Sum("planned_hours"))["v"] or Decimal("0")
        actual = qs.aggregate(v=Sum("actual_hours"))["v"] or Decimal("0")
        team_utilisation = float(actual / planned * 100) if planned else 0
        return Response({
            "total_open": total_open, "awaiting_review": awaiting_review, "in_progress": in_progress,
            "overdue": overdue, "due_this_week": due_this_week, "resolved": resolved,
            "planned_hours": float(planned), "actual_hours": float(actual), "team_utilisation": round(team_utilisation, 1),
        })
