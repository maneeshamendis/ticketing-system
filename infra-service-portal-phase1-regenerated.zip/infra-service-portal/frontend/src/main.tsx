import React, { useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import {
  Activity, AlertCircle, BarChart3, CalendarDays, CheckCircle2, ChevronLeft, ChevronRight,
  Clock3, FileText, Home, LogOut, Menu, Plus, Search, Settings2, ShieldCheck,
  Ticket as TicketIcon, Users, XCircle, UserCheck, PauseCircle, PlayCircle
} from 'lucide-react'
import './styles.css'

type User = { id:number; username:string; name:string; email:string; role:string; role_display?:string; department:string }
type Category = { id:number; name:string; code:string; description:string; default_sla_hours:number; is_active:boolean }
type Team = { id:number; name:string; code:string; description:string; members:number[]; members_detail?:User[] }
type Ticket = {
  id:string; ticket_number:string; title:string; description:string; ticket_type:string; category:number|null;
  category_detail?:Category|null; requester:number; requester_detail:User; assigned_to:number|null; assigned_to_detail:User|null;
  assigned_team:number|null; assigned_team_detail?:Team|null; status:string; requester_priority:string; actual_priority:string;
  is_bau:boolean; budget_approval:boolean; security_signoff:boolean; boq_document:boolean; pmo_hours_allocated:string;
  requested_delivery_date:string|null; planned_start_date:string|null; delivery_date:string|null; planned_hours:number|null;
  actual_hours:number; actual_hours_computed:number; days_left:number|null; created_at:string; updated_at:string;
  resolution:string; comments:any[]; attachments:any[]; subtasks:any[]; worklogs:any[]; audit_logs:any[];
}
type Dashboard = { total_open:number; awaiting_review:number; in_progress:number; overdue:number; due_this_week:number; resolved:number; planned_hours:number; actual_hours:number; team_utilisation:number }

const priorityLabel:Record<string,string> = { P1:'P1 · Critical', P2:'P2 · High', P3:'P3 · Medium', P4:'P4 · Low' }
const statusLabel:Record<string,string> = { CREATED:'Created', MANAGER_REVIEW:'Manager Review', NEEDS_INFORMATION:'Needs Information', APPROVED:'Approved', ASSIGNED:'Assigned', IN_PROGRESS:'In Progress', ON_HOLD:'On Hold', RESOLVED:'Resolved', CLOSED:'Closed', REJECTED:'Rejected', CANCELLED:'Cancelled' }

async function api(path:string, options:RequestInit={}) {
  const token = localStorage.getItem('access')
  const headers = new Headers(options.headers)
  if (options.body && !(options.body instanceof FormData)) headers.set('Content-Type','application/json')
  if (token) headers.set('Authorization', `Bearer ${token}`)
  const res = await fetch(path, {...options, headers})
  if (res.status === 401) { localStorage.removeItem('access'); localStorage.removeItem('refresh'); window.location.reload() }
  if (!res.ok) {
    let detail = `${res.status} ${res.statusText}`
    try { const data = await res.json(); detail = data.detail || JSON.stringify(data) } catch {}
    throw new Error(detail)
  }
  return res.status === 204 ? null : res.json()
}

function App() {
  const [me,setMe] = useState<User|null>(null)
  const [loginError,setLoginError] = useState('')
  const [loginBusy,setLoginBusy] = useState(false)
  useEffect(() => { if (localStorage.getItem('access')) api('/api/auth/me/').then(setMe).catch(()=>{}) }, [])
  async function login(username:string,password:string) {
    setLoginBusy(true); setLoginError('')
    try {
      const res = await fetch('/api/auth/token/', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({username,password})})
      if (!res.ok) throw new Error('Invalid username or password')
      const tokens = await res.json(); localStorage.setItem('access',tokens.access); localStorage.setItem('refresh',tokens.refresh)
      setMe(await api('/api/auth/me/'))
    } catch(e:any) { setLoginError(e.message || 'Unable to sign in') }
    finally { setLoginBusy(false) }
  }
  if (!me) return <Login onLogin={login} error={loginError} busy={loginBusy}/>
  return <Portal user={me} onLogout={() => { localStorage.clear(); setMe(null) }}/>
}

function Login({onLogin,error,busy}:{onLogin:(u:string,p:string)=>void; error:string; busy:boolean}) {
  const [u,setU]=useState('admin'); const [p,setP]=useState('admin')
  return <div className="login-shell"><div className="login-card">
    <div className="brand-mark">IS</div><h1>Infrastructure Service Portal</h1><p className="muted">Internal IT service management</p>
    <label>Username<input value={u} onChange={e=>setU(e.target.value)} autoFocus/></label>
    <label>Password<input type="password" value={p} onChange={e=>setP(e.target.value)} onKeyDown={e=>e.key==='Enter'&&onLogin(u,p)}/></label>
    {error && <div className="alert error"><AlertCircle size={16}/>{error}</div>}
    <button className="primary full" disabled={busy} onClick={()=>onLogin(u,p)}>{busy?'Signing in…':'Sign in'}</button>
    <div className="login-note"><ShieldCheck size={16}/> Local authentication is enabled for the MVP. AD / OIDC SSO is the next identity phase.</div>
  </div></div>
}

function Portal({user,onLogout}:{user:User; onLogout:()=>void}) {
  const [view,setView] = useState('dashboard'); const [selected,setSelected] = useState<string|null>(null); const [collapsed,setCollapsed] = useState(false)
  const manager = ['MANAGER','SUPERADMIN'].includes(user.role); const agent = ['INFRA_AGENT','MANAGER','SUPERADMIN'].includes(user.role)
  const nav:any[] = [
    ['dashboard','Dashboard',Home],['tickets','Tickets',TicketIcon],['new','New Request',Plus],['planning','My Calendar',CalendarDays],
    ...(manager ? [['team','Team Planning',Users],['reports','Reports',BarChart3],['admin','Administration',Settings2]] : [])
  ]
  return <div className="app-shell">
    <aside className={collapsed?'sidebar collapsed':'sidebar'}><div className="sidebar-head"><div className="brand-mark small">IS</div>{!collapsed&&<div><strong>Infra Portal</strong><span>Service Management</span></div>}<button className="icon-btn" onClick={()=>setCollapsed(!collapsed)}><Menu size={18}/></button></div>
      <nav>{nav.map(([id,label,Icon])=><button key={id} className={view===id?'nav-item active':'nav-item'} onClick={()=>{setView(id);setSelected(null)}}><Icon size={18}/>{!collapsed&&<span>{label}</span>}</button>)}</nav>
      <div className="sidebar-bottom">{!collapsed&&<div className="user-mini"><div className="avatar">{user.name.charAt(0).toUpperCase()}</div><div><strong>{user.name}</strong><span>{(user.role_display||user.role).replaceAll('_',' ')}</span></div></div>}<button className="nav-item" onClick={onLogout}><LogOut size={18}/>{!collapsed&&<span>Sign out</span>}</button></div>
    </aside>
    <main className="main">
      {view==='dashboard' && <Dashboard user={user} manager={manager} onOpen={(id)=>{setSelected(id);setView('ticket')}} onViewTickets={()=>{setView('tickets');setSelected(null)}}/>}
      {view==='tickets' && <TicketList user={user} manager={manager} onOpen={(id)=>{setSelected(id);setView('ticket')}} onNew={()=>{setView('new');setSelected(null)}}/>}
      {view==='new' && <NewRequest onCreated={(id)=>{setSelected(id);setView('ticket')}}/>}
      {view==='ticket' && selected && <TicketDetail id={selected} user={user} canWork={agent} canManage={manager} onBack={()=>setView('tickets')}/>} 
      {view==='planning' && <Planning user={user} manager={false}/>} 
      {view==='team' && <Planning user={user} manager/>}
      {view==='reports' && <Reports/>}
      {view==='admin' && <Admin/>}
    </main>
  </div>
}

function PageHeader({eyebrow,title,action}:{eyebrow:string;title:string;action?:React.ReactNode}) { return <div className="page-header"><div><div className="eyebrow">{eyebrow}</div><h2>{title}</h2></div>{action}</div> }
function Metric({label,value,icon:Icon,sub}:{label:string;value:string|number;icon:any;sub?:string}) { return <div className="metric"><div className="metric-icon"><Icon size={18}/></div><div><div className="metric-label">{label}</div><div className="metric-value">{value}</div>{sub&&<div className="metric-sub">{sub}</div>}</div></div> }
function StatusPill({status}:{status:string}) { return <span className={`pill status-${status.toLowerCase()}`}>{statusLabel[status]||status}</span> }
function PriorityPill({priority}:{priority:string}) { return <span className={`pill priority-${priority.toLowerCase()}`}>{priorityLabel[priority]||priority}</span> }

function Dashboard({user,manager,onOpen,onViewTickets}:{user:User;manager:boolean;onOpen:(id:string)=>void;onViewTickets:()=>void}) {
  const [d,setD]=useState<Dashboard|null>(null); const [tickets,setTickets]=useState<Ticket[]>([])
  useEffect(()=>{Promise.all([api('/api/dashboard/'),api('/api/tickets/?page_size=8&ordering=-created_at')]).then(([a,b])=>{setD(a);setTickets(b.results)}).catch(()=>{})},[])
  return <div className="page"><PageHeader eyebrow="Overview" title={`Good morning, ${user.name.split(' ')[0]}`} action={<button className="secondary" onClick={onViewTickets}>Open ticket queue</button>}/>
    {d&&<div className="metric-grid"><Metric label="Open tickets" value={d.total_open} icon={TicketIcon} sub="Active workload"/><Metric label="Awaiting review" value={d.awaiting_review} icon={Clock3} sub={manager?'Manager action':'Team review'}/><Metric label="In progress" value={d.in_progress} icon={Activity} sub="Being delivered"/><Metric label="Overdue" value={d.overdue} icon={AlertCircle} sub="Needs attention"/></div>}
    <div className="two-col"><section className="card"><div className="section-head"><div><h3>Recent tickets</h3><p className="muted">Latest service requests and operational work</p></div><button className="ghost" onClick={onViewTickets}>View all <ChevronRight size={15}/></button></div>
      <div className="ticket-table">{tickets.map(t=><button className="ticket-row" key={t.id} onClick={()=>onOpen(t.id)}><div><strong>{t.ticket_number}</strong><span>{t.title}</span></div><PriorityPill priority={t.actual_priority}/><StatusPill status={t.status}/><div className={t.days_left!==null&&t.days_left<0?'due overdue':'due'}>{t.days_left===null?'—':t.days_left<0?`${Math.abs(t.days_left)}d overdue`:`${t.days_left}d left`}</div><ChevronRight size={16}/></button>)}</div>
    </section><section className="card"><div className="section-head"><div><h3>Delivery pulse</h3><p className="muted">Planned vs actual effort</p></div></div>{d&&<><div className="big-number">{Math.round(d.team_utilisation)}<span>%</span></div><div className="muted">Actual hours against planned hours</div><div className="progress"><div style={{width:`${Math.min(d.team_utilisation,100)}%`}}/></div><div className="stat-line"><span>Planned</span><strong>{d.planned_hours}h</strong></div><div className="stat-line"><span>Actual</span><strong>{d.actual_hours}h</strong></div><div className="stat-line"><span>Due this week</span><strong>{d.due_this_week}</strong></div><div className="stat-line"><span>Resolved</span><strong>{d.resolved}</strong></div></>}</section></div>
  </div>
}

function TicketList({user,manager,onOpen,onNew}:{user:User;manager:boolean;onOpen:(id:string)=>void;onNew:()=>void}) {
  const [rows,setRows]=useState<Ticket[]>([]); const [q,setQ]=useState(''); const [status,setStatus]=useState(''); const [priority,setPriority]=useState(''); const [busy,setBusy]=useState(false); const [queue,setQueue]=useState('')
  async function load(extraStatus=status){setBusy(true);try{const params=new URLSearchParams({page_size:'100'});if(q)params.set('search',q);if(extraStatus)params.set('status',extraStatus);if(priority)params.set('actual_priority',priority);const data=await api(`/api/tickets/?${params}`);setRows(data.results)}finally{setBusy(false)}}
  useEffect(()=>{load(queue)},[status,priority,queue])
  const statuses = Object.entries(statusLabel)
  return <div className="page"><PageHeader eyebrow="Work queue" title="Tickets" action={<button className="primary" onClick={onNew}><Plus size={17}/>New request</button>}/>
    {manager&&<div className="queue-strip"><button className={queue===''?'queue-btn active':'queue-btn'} onClick={()=>setQueue('')}>All</button><button className={queue==='CREATED'?'queue-btn active':'queue-btn'} onClick={()=>setQueue('CREATED')}>New</button><button className={queue==='MANAGER_REVIEW'?'queue-btn active':'queue-btn'} onClick={()=>setQueue('MANAGER_REVIEW')}>Needs review</button><button className={queue==='APPROVED'?'queue-btn active':'queue-btn'} onClick={()=>setQueue('APPROVED')}>Approved</button><button className={queue==='ASSIGNED'?'queue-btn active':'queue-btn'} onClick={()=>setQueue('ASSIGNED')}>Assigned</button><button className={queue==='IN_PROGRESS'?'queue-btn active':'queue-btn'} onClick={()=>setQueue('IN_PROGRESS')}>In progress</button><button className={queue==='ON_HOLD'?'queue-btn active':'queue-btn'} onClick={()=>setQueue('ON_HOLD')}>On hold</button></div>}
    <div className="toolbar card"><div className="search"><Search size={17}/><input placeholder="Search ticket, title or description" value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==='Enter'&&load(queue)}/></div><select value={status} onChange={e=>{setStatus(e.target.value);setQueue(e.target.value)}}><option value="">All statuses</option>{statuses.map(([k,v])=><option key={k} value={k}>{v}</option>)}</select><select value={priority} onChange={e=>setPriority(e.target.value)}><option value="">All priorities</option>{Object.entries(priorityLabel).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></div>
    <section className="card"><div className="ticket-table table-header"><div>Ticket</div><div>Priority</div><div>Status</div><div>Delivery</div><div/></div>{busy?<div className="empty">Loading tickets…</div>:rows.length===0?<div className="empty">No tickets found.</div>:rows.map(t=><button className="ticket-row table" key={t.id} onClick={()=>onOpen(t.id)}><div><strong>{t.ticket_number}</strong><span>{t.title}</span><small className="muted">{t.requester_detail?.name} · {t.assigned_to_detail?.name||'Unassigned'}</small></div><PriorityPill priority={t.actual_priority}/><StatusPill status={t.status}/><div className={t.days_left!==null&&t.days_left<0?'due overdue':'due'}>{t.delivery_date||'Not planned'}{t.days_left!==null&&<small>{t.days_left<0?` · ${Math.abs(t.days_left)}d overdue`:` · ${t.days_left}d left`}</small>}</div><ChevronRight size={16}/></button>)}</section>
  </div>
}

function NewRequest({onCreated}:{onCreated:(id:string)=>void}) {
  const [cats,setCats]=useState<Category[]>([]); const [busy,setBusy]=useState(false); const [error,setError]=useState('')
  const [f,setF]=useState<any>({title:'',description:'',ticket_type:'SERVICE_REQUEST',category:'',requester_priority:'P3',requested_delivery_date:'',is_bau:false,budget_approval:false,security_signoff:false,boq_document:false,pmo_hours_allocated:'N/A'})
  const [file,setFile]=useState<File|null>(null)
  useEffect(()=>{api('/api/categories/?page_size=100').then(d=>setCats(d.results)).catch(()=>{})},[])
  const set=(k:string,v:any)=>setF((x:any)=>({...x,[k]:v}))
  async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setError('');try{if(f.boq_document&&!file)throw new Error('Please attach the BOQ Excel file when BOQ Document is selected.');if(file&&!/\.(xlsx|xlsm)$/i.test(file.name))throw new Error('BOQ document must be an Excel .xlsx or .xlsm file.');const payload={...f,category:f.category?Number(f.category):null,requested_delivery_date:f.requested_delivery_date||null};const t=await api('/api/tickets/',{method:'POST',body:JSON.stringify(payload)});if(file){const form=new FormData();form.append('ticket',t.id);form.append('file',file);await api('/api/attachments/',{method:'POST',body:form})}onCreated(t.id)}catch(e:any){setError(e.message)}finally{setBusy(false)}}
  return <div className="page"><PageHeader eyebrow="Service catalogue" title="New infrastructure request"/><form className="card form-card" onSubmit={submit}>{error&&<div className="alert error"><AlertCircle size={16}/>{error}</div>}<div className="form-grid">
    <label className="span-2">Request title<input required value={f.title} onChange={e=>set('title',e.target.value)} placeholder="e.g. Create production Linux server"/></label>
    <label>Request type<select value={f.ticket_type} onChange={e=>set('ticket_type',e.target.value)}><option value="SERVICE_REQUEST">Service Request</option><option value="INCIDENT">Incident</option><option value="CHANGE">Change</option><option value="PROBLEM">Problem</option></select></label>
    <label>Category<select value={f.category} onChange={e=>set('category',e.target.value)}><option value="">Select category</option>{cats.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
    <label className="span-2">Description<textarea required rows={5} value={f.description} onChange={e=>set('description',e.target.value)} placeholder="Describe the requirement, business context and expected outcome…"/></label>
    <label>Requested delivery date<input type="date" value={f.requested_delivery_date} onChange={e=>set('requested_delivery_date',e.target.value)}/></label>
    <label>Suggested priority<select value={f.requester_priority} onChange={e=>set('requester_priority',e.target.value)}>{Object.entries(priorityLabel).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></label>
    <div className="span-2 subsection"><h4>Governance & prerequisites</h4><div className="checks">{[['budget_approval','Budget approval'],['security_signoff','Security sign-off'],['boq_document','BOQ document'],['is_bau','BAU requirement']].map(([k,l])=><label className="check" key={k}><input type="checkbox" checked={!!f[k]} onChange={e=>set(k,e.target.checked)}/><span>{l}</span></label>)}</div></div>
    <label>PMO hours allocated<select value={f.pmo_hours_allocated} onChange={e=>set('pmo_hours_allocated',e.target.value)}><option value="YES">Yes</option><option value="NO">No</option><option value="N/A">N/A</option></select></label>
    <label>BOQ Excel upload<input type="file" accept=".xlsx,.xlsm" onChange={e=>setFile(e.target.files?.[0]||null)} disabled={!f.boq_document}/>{f.boq_document&&<small className="muted">Required when BOQ Document is selected.</small>}</label>
  </div><div className="form-footer"><div className="muted">Your priority is a suggestion. The Infrastructure manager sets the actual priority during review.</div><button className="primary" disabled={busy}>{busy?'Submitting…':'Submit request'}</button></div></form></div>
}

function TicketDetail({id,user,canWork,canManage,onBack}:{id:string;user:User;canWork:boolean;canManage:boolean;onBack:()=>void}) {
  const [t,setT]=useState<Ticket|null>(null); const [users,setUsers]=useState<User[]>([]); const [teams,setTeams]=useState<Team[]>([]); const [comment,setComment]=useState(''); const [subtask,setSubtask]=useState(''); const [work,setWork]=useState(''); const [error,setError]=useState(''); const [busy,setBusy]=useState(false)
  const [review,setReview]=useState({priority:'P3',delivery:'',start:'',hours:'',assignee:'',team:'',decisionNote:''})
  async function load(){try{const data=await api(`/api/tickets/${id}/`);setT(data);setReview(v=>({...v,priority:data.actual_priority,delivery:data.delivery_date||data.requested_delivery_date||'',start:data.planned_start_date||'',hours:data.planned_hours?.toString()||'',assignee:data.assigned_to?.toString()||'',team:data.assigned_team?.toString()||''}))}catch(e:any){setError(e.message)}}
  useEffect(()=>{load();if(canManage){Promise.all([api('/api/users/?page_size=100&is_active=true'),api('/api/teams/?page_size=100&is_active=true')]).then(([u,tm])=>{setUsers(u.results.filter((x:User)=>['INFRA_AGENT','MANAGER','SUPERADMIN'].includes(x.role)));setTeams(tm.results)}).catch(()=>{})}},[id,canManage])
  if(!t)return <div className="page"><div className="loading">Loading ticket…</div>{error&&<div className="alert error">{error}</div>}</div>
  const ticket=t
  const canClaim=canWork&&!ticket.assigned_to&&['APPROVED','ASSIGNED'].includes(ticket.status)
  const isAssignee=canWork&&ticket.assigned_to===user.id
  async function request(fn:()=>Promise<any>){setBusy(true);setError('');try{await fn();await load()}catch(e:any){setError(e.message)}finally{setBusy(false)}}
  async function transition(status:string){await request(()=>api(`/api/tickets/${id}/transition/`,{method:'POST',body:JSON.stringify({status})}))}
  async function claim(){await request(()=>api(`/api/tickets/${id}/claim/`,{method:'POST'}))}
  async function startReview(){await request(()=>api(`/api/tickets/${id}/start_review/`,{method:'POST'}))}
  async function addComment(visibility='PUBLIC'){if(!comment.trim())return;await request(async()=>{await api(`/api/tickets/${id}/comment/`,{method:'POST',body:JSON.stringify({body:comment,visibility})});setComment('')})}
  async function createSubtask(){if(!subtask.trim())return;await request(async()=>{await api('/api/subtasks/',{method:'POST',body:JSON.stringify({ticket:id,title:subtask,status:'TODO',priority:ticket.actual_priority})});setSubtask('')})}
  async function logWork(){const hours=Number(work);if(!hours)return;await request(async()=>{await api('/api/worklogs/',{method:'POST',body:JSON.stringify({ticket:id,work_date:new Date().toISOString().slice(0,10),hours,description:'Work logged from portal'})});setWork('')})}
  async function submitReview(decision:string){if(decision==='APPROVE'&&(!review.delivery||!review.hours))return setError('Delivery date and planned hours are required for approval.');await request(()=>api(`/api/tickets/${id}/review/`,{method:'POST',body:JSON.stringify({decision,actual_priority:review.priority,delivery_date:review.delivery||null,planned_start_date:review.start||null,planned_hours:review.hours||null,assigned_to:review.assignee||null,assigned_team:review.team||null,note:review.decisionNote})}))}
  async function assign(){if(!review.assignee&&!review.team)return setError('Select an assignee or team.');await request(()=>api(`/api/tickets/${id}/assign/`,{method:'POST',body:JSON.stringify({assigned_to:review.assignee||null,assigned_team:review.team||null})}))}
  return <div className="page">
    <PageHeader eyebrow={ticket.ticket_number} title={ticket.title} action={<div className="header-actions"><button className="ghost" onClick={onBack}><ChevronLeft size={16}/>Back to queue</button>{canManage&&ticket.status==='CREATED'&&<button className="secondary" disabled={busy} onClick={startReview}>Start review</button>}{canClaim&&<button className="secondary" disabled={busy} onClick={claim}><UserCheck size={16}/>Claim ticket</button>}{isAssignee&&ticket.status==='ASSIGNED'&&<button className="primary" disabled={busy} onClick={()=>transition('IN_PROGRESS')}><PlayCircle size={16}/>Start work</button>}{isAssignee&&ticket.status==='IN_PROGRESS'&&<button className="secondary" disabled={busy} onClick={()=>transition('ON_HOLD')}><PauseCircle size={16}/>Put on hold</button>}{isAssignee&&ticket.status==='ON_HOLD'&&<button className="primary" disabled={busy} onClick={()=>transition('IN_PROGRESS')}><PlayCircle size={16}/>Resume</button>}{isAssignee&&ticket.status==='IN_PROGRESS'&&<button className="secondary" disabled={busy} onClick={()=>transition('RESOLVED')}><CheckCircle2 size={16}/>Resolve</button>}{canManage&&ticket.status==='RESOLVED'&&<button className="primary" disabled={busy} onClick={()=>transition('CLOSED')}><CheckCircle2 size={16}/>Close</button>}</div>}/>
    {error&&<div className="alert error"><AlertCircle size={16}/>{error}</div>}
    <div className="ticket-detail-grid"><div className="left-stack">
      <section className="card"><div className="ticket-title-line"><div><div className="ticket-num">{ticket.ticket_number}</div><h3>{ticket.title}</h3></div><div className="pill-row"><PriorityPill priority={ticket.actual_priority}/><StatusPill status={ticket.status}/></div></div><div className="description">{ticket.description}</div><div className="detail-meta"><div><span>Requester</span><strong>{ticket.requester_detail?.name}</strong></div><div><span>Requester priority</span><strong><PriorityPill priority={ticket.requester_priority}/></strong></div><div><span>Actual priority</span><strong><PriorityPill priority={ticket.actual_priority}/></strong></div><div><span>Assignee</span><strong>{ticket.assigned_to_detail?.name||'Unassigned'}</strong></div><div><span>Team</span><strong>{ticket.assigned_team_detail?.name||'—'}</strong></div><div><span>Requested delivery</span><strong>{ticket.requested_delivery_date||'—'}</strong></div></div></section>
      {canManage&&['CREATED','MANAGER_REVIEW'].includes(ticket.status)&&<section className="card manager-review"><div className="section-head"><div><h3>Manager review & planning</h3><p className="muted">Set the commitment before approving the request.</p></div><StatusPill status={ticket.status}/></div><div className="review-summary"><div><span>Requester priority</span><strong><PriorityPill priority={ticket.requester_priority}/></strong></div><div><span>Requested date</span><strong>{ticket.requested_delivery_date||'Not specified'}</strong></div><div><span>BAU</span><strong>{ticket.is_bau?'YES':'NO'}</strong></div></div>{ticket.status==='CREATED'&&<div className="alert info"><Clock3 size={16}/>Start review to record the manager decision and planning commitment.</div>}<div className="form-grid"><label>Actual priority<select value={review.priority} onChange={e=>setReview(x=>({...x,priority:e.target.value}))}>{Object.entries(priorityLabel).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></label><label>Delivery date<input type="date" value={review.delivery} onChange={e=>setReview(x=>({...x,delivery:e.target.value}))}/></label><label>Planned start date<input type="date" value={review.start} onChange={e=>setReview(x=>({...x,start:e.target.value}))}/></label><label>Planned hours<input type="number" min="0.25" step="0.25" value={review.hours} onChange={e=>setReview(x=>({...x,hours:e.target.value}))}/></label><label>Assign resource<select value={review.assignee} onChange={e=>setReview(x=>({...x,assignee:e.target.value}))}><option value="">Unassigned / team pickup</option>{users.map(u=><option key={u.id} value={u.id}>{u.name} · {u.role.replaceAll('_',' ')}</option>)}</select></label><label>Assign team<select value={review.team} onChange={e=>setReview(x=>({...x,team:e.target.value}))}><option value="">No team change</option>{teams.map(tm=><option key={tm.id} value={tm.id}>{tm.name}</option>)}</select></label><label className="span-2">Manager note<textarea rows={3} value={review.decisionNote} onChange={e=>setReview(x=>({...x,decisionNote:e.target.value}))} placeholder="Explain the decision or tell the requester what information is missing…"/></label></div><div className="form-footer"><div className="muted">Approve requires a delivery date and planned hours. A review note for NEEDS INFORMATION is shown to the requester.</div><div className="button-row"><button className="secondary" disabled={busy||ticket.status==='CREATED'} onClick={()=>submitReview('NEEDS_INFORMATION')}>Need information</button><button className="danger" disabled={busy||ticket.status==='CREATED'} onClick={()=>submitReview('REJECT')}>Reject</button><button className="primary" disabled={busy||ticket.status==='CREATED'} onClick={()=>submitReview('APPROVE')}>Approve & plan</button></div></div></section>}
      {canManage&&['APPROVED','ASSIGNED'].includes(ticket.status)&&<section className="card"><div className="section-head"><div><h3>Assignment</h3><p className="muted">Change resource or team after approval.</p></div><StatusPill status={ticket.status}/></div><div className="form-grid"><label>Resource<select value={review.assignee||ticket.assigned_to?.toString()||''} onChange={e=>setReview(x=>({...x,assignee:e.target.value}))}><option value="">Unassigned / team pickup</option>{users.map(u=><option key={u.id} value={u.id}>{u.name} · {u.role.replaceAll('_',' ')}</option>)}</select></label><label>Team<select value={review.team||ticket.assigned_team?.toString()||''} onChange={e=>setReview(x=>({...x,team:e.target.value}))}><option value="">No team change</option>{teams.map(tm=><option key={tm.id} value={tm.id}>{tm.name}</option>)}</select></label></div><div className="form-footer"><span className="muted">A team assignment can be left for self-pickup.</span><button className="secondary" disabled={busy} onClick={assign}>Save assignment</button></div></section>}
      {user.role==='REQUESTER'&&ticket.status==='NEEDS_INFORMATION'&&<section className="card action-card"><div><h3>Have you provided the requested information?</h3><p className="muted">Submit the ticket back to manager review once your response is added.</p></div><button className="primary" disabled={busy} onClick={()=>transition('MANAGER_REVIEW')}>Send back for review</button></section>}
      <section className="card"><div className="section-head"><div><h3>Activity</h3><p className="muted">Comments, decisions and audit history</p></div></div><div className="timeline">{ticket.comments.map((c:any)=><div className="timeline-item" key={`c${c.id}`}><div className="avatar small">{c.author_detail.name.charAt(0)}</div><div><div><strong>{c.author_detail.name}</strong><span className="muted"> · {new Date(c.created_at).toLocaleString()}</span></div><p>{c.body}</p>{c.visibility==='INTERNAL'&&<span className="pill internal">Internal</span>}</div></div>)}{ticket.audit_logs.slice(0,12).map((a:any)=><div className="timeline-item audit" key={`a${a.id}`}><div className="audit-dot"><Activity size={13}/></div><div><strong>{a.action.replaceAll('_',' ')}</strong><span className="muted"> · {new Date(a.created_at).toLocaleString()}</span></div></div>)}</div><div className="comment-box"><textarea value={comment} onChange={e=>setComment(e.target.value)} placeholder="Write a comment…" rows={3}/><div><button className="secondary" disabled={busy} onClick={()=>addComment('PUBLIC')}>Add comment</button>{canWork&&<button className="ghost" disabled={busy} onClick={()=>addComment('INTERNAL')}>Internal note</button>}</div></div></section>
    </div><div className="right-stack"><section className="card"><h3>Delivery</h3><div className={`days-left ${ticket.days_left!==null&&ticket.days_left<0?'overdue':''}`}>{ticket.days_left===null?'Not planned':ticket.days_left<0?`${Math.abs(ticket.days_left)} days overdue`:`${ticket.days_left} days left`}</div><div className="stat-line"><span>Start</span><strong>{ticket.planned_start_date||'—'}</strong></div><div className="stat-line"><span>Due</span><strong>{ticket.delivery_date||'—'}</strong></div><div className="stat-line"><span>Planned</span><strong>{ticket.planned_hours??0}h</strong></div><div className="stat-line"><span>Actual</span><strong>{ticket.actual_hours_computed}h</strong></div></section>
      <section className="card"><div className="section-head"><div><h3>Subtasks</h3><p className="muted">{ticket.subtasks.filter((s:any)=>s.status==='DONE').length} / {ticket.subtasks.length} complete</p></div></div>{ticket.subtasks.map((s:any)=><div className="subtask" key={s.id}><div><strong>{s.title}</strong><span>{s.assignee_detail?.name||'Unassigned'} · {s.due_date||'No due date'}</span></div><StatusPill status={s.status}/></div>)}{canWork&&<div className="inline-add"><input value={subtask} onChange={e=>setSubtask(e.target.value)} placeholder="New subtask"/><button className="secondary" disabled={busy} onClick={createSubtask}><Plus size={16}/></button></div>}</section>
      {canWork&&<section className="card"><h3>Log work</h3><div className="inline-add"><input value={work} onChange={e=>setWork(e.target.value)} type="number" min="0.25" step="0.25" placeholder="Hours"/><button className="primary" disabled={busy} onClick={logWork}>Log</button></div></section>}
      <section className="card"><h3>Attachments</h3>{ticket.attachments.length===0?<div className="empty"><FileText size={18}/>No attachments</div>:ticket.attachments.map((a:any)=><a className="attachment" key={a.id} href={a.file} target="_blank" rel="noreferrer"><FileText size={17}/><span>{a.original_name}</span></a>)}</section>
      <section className="card"><h3>Governance</h3><div className="governance"><div><span>Budget approval</span><strong>{ticket.budget_approval?'YES':'NO'}</strong></div><div><span>Security sign-off</span><strong>{ticket.security_signoff?'YES':'NO'}</strong></div><div><span>BOQ document</span><strong>{ticket.boq_document?'YES':'NO'}</strong></div><div><span>PMO hours</span><strong>{ticket.pmo_hours_allocated}</strong></div><div><span>BAU</span><strong>{ticket.is_bau?'YES':'NO'}</strong></div></div></section>
    </div></div>
  </div>
}

function Planning({user,manager}:{user:User;manager:boolean}) {
  const [alloc,setAlloc]=useState<any[]>([]); const [users,setUsers]=useState<User[]>([]); const [weekStart,setWeekStart]=useState(()=>{const d=new Date();const day=(d.getDay()+6)%7;d.setDate(d.getDate()-day);return d.toISOString().slice(0,10)}); const [newAlloc,setNewAlloc]=useState({user:'',date:'',hours:'',ticket:'',note:''}); const [error,setError]=useState('')
  const days=Array.from({length:7},(_,i)=>{const d=new Date(`${weekStart}T00:00:00`);d.setDate(d.getDate()+i);return {date:d.toISOString().slice(0,10),label:d.toLocaleDateString(undefined,{weekday:'short',day:'2-digit'})}})
  async function load(){try{const arr=await Promise.all(days.map(d=>api(`/api/allocations/?allocation_date=${d.date}&page_size=200${manager?'':`&user=${user.id}`}`)));setAlloc(arr.flatMap(x=>x.results))}catch(e:any){setError(e.message)}}
  useEffect(()=>{setNewAlloc(x=>({...x,date:x.date||weekStart}));load();if(manager)api('/api/users/?page_size=100&is_active=true').then(d=>setUsers(d.results.filter((u:User)=>['INFRA_AGENT','MANAGER','SUPERADMIN'].includes(u.role)))).catch(()=>{})},[weekStart,manager])
  const byDay=(date:string)=>alloc.filter(a=>a.allocation_date===date); const totals=users.map(u=>({u,total:alloc.filter(a=>a.user===u.id).reduce((s:number,a:any)=>s+Number(a.hours),0)}))
  async function createAllocation(){setError('');try{if(!newAlloc.user||!newAlloc.hours||!newAlloc.date)throw new Error('Select resource, date and hours.');await api('/api/allocations/',{method:'POST',body:JSON.stringify({user:Number(newAlloc.user),allocation_date:newAlloc.date,hours:Number(newAlloc.hours),ticket:newAlloc.ticket||null,note:newAlloc.note})});setNewAlloc(x=>({...x,hours:'',ticket:'',note:''}));load()}catch(e:any){setError(e.message)}}
  return <div className="page"><PageHeader eyebrow={manager?'Capacity management':'Personal capacity'} title={manager?'Team planning':'My calendar'} action={<input className="date-pick" type="date" value={weekStart} onChange={e=>setWeekStart(e.target.value)}/>}/>{error&&<div className="alert error"><AlertCircle size={16}/>{error}</div>}
    {manager&&<section className="card allocation-form"><div className="section-head"><div><h3>Allocate work</h3><p className="muted">Assign hours for a person on a day. The ticket number can be linked later in the ticket picker.</p></div></div><div className="form-grid"><label>Resource<select value={newAlloc.user} onChange={e=>setNewAlloc(x=>({...x,user:e.target.value}))}><option value="">Select person</option>{users.map(u=><option key={u.id} value={u.id}>{u.name}</option>)}</select></label><label>Date<input type="date" value={newAlloc.date||weekStart} min={days[0].date} max={days[6].date} onChange={e=>setNewAlloc(x=>({...x,date:e.target.value}))}/></label><label>Hours<input type="number" min="0.25" max="24" step="0.25" value={newAlloc.hours} onChange={e=>setNewAlloc(x=>({...x,hours:e.target.value}))}/></label><label>Ticket UUID (optional)<input value={newAlloc.ticket} onChange={e=>setNewAlloc(x=>({...x,ticket:e.target.value}))} placeholder="Paste ticket UUID"/></label><label className="span-2">Note<input value={newAlloc.note} onChange={e=>setNewAlloc(x=>({...x,note:e.target.value}))} placeholder="Patch window, project work, operational duty…"/></label></div><div className="form-footer"><span className="muted">Week: {days[0].date} → {days[6].date}</span><button className="primary" onClick={createAllocation}>Add allocation</button></div></section>}
    {manager&&<section className="capacity-strip card"><div><span>Team allocations</span><strong>{alloc.reduce((s:number,a:any)=>s+Number(a.hours),0)}h</strong></div>{totals.slice(0,6).map(x=><div key={x.u.id}><span>{x.u.name}</span><strong>{x.total}h / 40h</strong></div>)}</section>}
    <section className="card"><div className="calendar-grid">{days.map(day=><div className="day-column" key={day.date}><div className="day-header"><strong>{day.label}</strong><span>{byDay(day.date).reduce((s:number,a:any)=>s+Number(a.hours),0)}h</span></div>{byDay(day.date).length===0?<div className="day-empty">No work</div>:byDay(day.date).map(a=><div className="allocation" key={a.id}><span>{a.ticket_number||'Capacity'}</span><small>{a.user_detail?.name||user.name} · {a.hours}h</small><small>{a.note}</small></div>)}</div>)}</div></section>
  </div>
}

function Reports(){const [d,setD]=useState<Dashboard|null>(null);useEffect(()=>{api('/api/dashboard/').then(setD).catch(()=>{})},[]);return <div className="page"><PageHeader eyebrow="Management reporting" title="Operational reports"/><div className="metric-grid">{d&&<><Metric label="Open backlog" value={d.total_open} icon={TicketIcon}/><Metric label="Overdue" value={d.overdue} icon={AlertCircle}/><Metric label="Due this week" value={d.due_this_week} icon={CalendarDays}/><Metric label="Utilisation" value={`${Math.round(d.team_utilisation)}%`} icon={BarChart3}/></>}</div><div className="two-col"><section className="card"><h3>Current report views</h3>{['Open tickets','Overdue tickets','Backlog aging','Planned vs actual hours','Engineer workload','BAU vs project','Priority distribution'].map(x=><div className="report-link" key={x}><BarChart3 size={16}/><span>{x}</span><ChevronRight size={16}/></div>)}<div className="notice">SLA compliance and advanced exports are scheduled for the next ITSM phase.</div></section><section className="card"><h3>Planned vs actual</h3>{d&&<div className="chart-bars"><div><span>Planned</span><div className="bar"><i style={{width:'100%'}}/></div><strong>{d.planned_hours}h</strong></div><div><span>Actual</span><div className="bar"><i style={{width:`${d.planned_hours?Math.min(d.actual_hours/d.planned_hours*100,100):0}%`}}/></div><strong>{d.actual_hours}h</strong></div></div>}</section></div></div>}

function Admin(){return <div className="page"><PageHeader eyebrow="Administration" title="Platform administration"/><section className="card"><div className="admin-grid"><div><ShieldCheck/><h3>Roles</h3><p>Requester, Infra Agent, Manager and Superadmin are stored as application roles. AD / OIDC identity fields are ready for the SSO phase.</p></div><div><Users/><h3>User management</h3><p>Use Django admin for controlled user and team administration during the MVP.</p><a href="/admin/" target="_blank" rel="noreferrer">Open Django admin →</a></div><div><Settings2/><h3>Next configuration</h3><p>Service catalogue, approval rules, SLA policies, business hours and automation are intentionally reserved for later phases.</p></div></div></section></div>}

createRoot(document.getElementById('root')!).render(<React.StrictMode><App/></React.StrictMode>)
