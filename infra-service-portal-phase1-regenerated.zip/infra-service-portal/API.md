# Infrastructure Service Portal API

Base path: `/api/`

Authentication: JWT bearer token in the MVP. AD/OIDC SSO is planned as a future phase.

## Phase 1 workflow endpoints

### Start manager review
`POST /api/tickets/{id}/start_review/`

Manager/Superadmin only. Valid from `CREATED` or `NEEDS_INFORMATION`.

### Manager review decision
`POST /api/tickets/{id}/review/`

Manager/Superadmin only. Ticket must be `MANAGER_REVIEW`.

Example approval:

```json
{
  "decision": "APPROVE",
  "actual_priority": "P2",
  "planned_start_date": "2026-09-07",
  "delivery_date": "2026-09-10",
  "planned_hours": 16,
  "assigned_to": 2,
  "assigned_team": 1,
  "note": "Approved for this week's infrastructure capacity."
}
```

Decision values:

- `APPROVE`
- `REJECT`
- `NEEDS_INFORMATION`

Approval requires delivery date and planned hours. If an assignee is supplied, the ticket becomes `ASSIGNED`; otherwise it becomes `APPROVED` for team pickup.

### Assign ticket
`POST /api/tickets/{id}/assign/`

Manager/Superadmin only. Valid after approval/review. Supply `assigned_to`, `assigned_team`, or both.

### Claim ticket
`POST /api/tickets/{id}/claim/`

Infrastructure Agent/Manager/Superadmin. Only approved/unassigned team work can be claimed. Team membership is checked for non-manager agents.

### Controlled status transition
`POST /api/tickets/{id}/transition/`

The backend enforces a state transition matrix. Requesters can only cancel their own tickets or move `NEEDS_INFORMATION` back to `MANAGER_REVIEW`. Agents can progress work assigned to themselves. Managers can close resolved work.
