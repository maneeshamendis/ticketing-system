# API Quick Reference

Base URL: `/api/`

Authentication for the MVP uses JWT.

## Login

`POST /api/auth/token/`

```json
{"username":"admin","password":"admin"}
```

## Core endpoints

- `GET /api/dashboard/`
- `GET /api/tickets/`
- `POST /api/tickets/`
- `GET /api/tickets/{id}/`
- `POST /api/tickets/{id}/review/`
- `POST /api/tickets/{id}/assign/`
- `POST /api/tickets/{id}/claim/`
- `POST /api/tickets/{id}/transition/`
- `POST /api/tickets/{id}/comment/`
- `GET /api/subtasks/`
- `POST /api/subtasks/`
- `POST /api/attachments/` (multipart/form-data)
- `GET /api/worklogs/`
- `POST /api/worklogs/`
- `GET /api/allocations/`
- `POST /api/allocations/`
- `GET /api/users/`
- `GET /api/teams/`
- `GET /api/categories/`

For the full schema, use the DRF browsable API or generate OpenAPI documentation in the next phase.
