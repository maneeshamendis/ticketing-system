from datetime import timedelta
from decimal import Decimal
from django.contrib.auth import get_user_model
from django.db.models import Q, Sum
from django.utils import timezone
from rest_framework import status, viewsets, permissions
from rest_framework.decorators import action
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Team, Category, Ticket, TicketComment, Attachment, SubTask, WorkLog, ResourceAllocation, Approval, AuditLog
from .serializers import (
    UserSerializer, TeamSerializer, CategorySerializer, TicketSerializer, TicketCommentSerializer,
    AttachmentSerializer, SubTaskSerializer, WorkLogSerializer, ResourceAllocationSerializer,
)

User = get_user_model()

class RolePermission(permissions.BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated)

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all().order_by("first_name", "last_name", "username")
    serializer_class = UserSerializer
    permission_classes = [RolePermission]
    filterset_fields = ["role", "department", "is_active"]
    search_fields = ["username", "first_name", "last_name", "email", "ad_username"]

    def perform_update(self, serializer):
        # Only superadmins can change roles and SSO identity fields.
        if not (self.request.user.is_superuser or self.request.user.role == User.Roles.SUPERADMIN):
            blocked = {"role", "ad_username", "oidc_subject", "is_ssm_managed"}
            if blocked & set(serializer.validated_data.keys()):
                raise permissions.PermissionDenied("Only superadmins can manage role/SSO identity fields.")
        serializer.save()

class TeamViewSet(viewsets.ModelViewSet):
    queryset = Team.objects.prefetch_related("members").all()
    serializer_class = TeamSerializer
    permission_classes = [RolePermission]
    search_fields = ["name", "code"]

class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [RolePermission]
    search_fields = ["name", "code"]

class TicketViewSet(viewsets.ModelViewSet):
    queryset = Ticket.objects.select_related("requester", "assigned_to", "assigned_team", "category").prefetch_related("comments", "attachments", "subtasks", "worklogs", "approvals", "audit_logs")
    serializer_class = TicketSerializer
    permission_classes = [RolePermission]
    filterset_fields = ["status", "actual_priority", "requester_priority", "ticket_type", "category", "assigned_to", "assigned_team", "is_bau"]
    search_fields = ["ticket_number", "title", "description"]
    ordering_fields = ["created_at", "updated_at", "delivery_date", "actual_priority"]

    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user
        if user.role == User.Roles.REQUESTER and not user.is_superuser:
            qs = qs.filter(requester=user)
        return qs

    def perform_create(self, serializer):
        data = self.request.data
        requester_priority = data.get("requester_priority", Ticket.Priority.P3)
        ticket = serializer.save(
            requester=self.request.user,
            actual_priority=requester_priority,
            status=Ticket.Status.CREATED,
        )
        AuditLog.objects.create(ticket=ticket, actor=self.request.user, action="TICKET_CREATED", after={"status": ticket.status, "requester_priority": ticket.requester_priority})

    def perform_update(self, serializer):
        if self.request.user.role == User.Roles.REQUESTER and not self.request.user.is_superuser:
            allowed = {"title", "description", "requested_delivery_date", "requester_priority", "is_bau"}
            incoming = set(serializer.validated_data.keys())
            blocked = incoming - allowed
            if blocked:
                raise permissions.PermissionDenied("Requesters cannot modify manager-controlled fields: " + ", ".join(sorted(blocked)))
        ticket = serializer.instance
        before = {"status": ticket.status, "actual_priority": ticket.actual_priority, "assigned_to": ticket.assigned_to_id, "delivery_date": str(ticket.delivery_date) if ticket.delivery_date else None, "planned_hours": float(ticket.planned_hours) if ticket.planned_hours is not None else None}
        ticket = serializer.save()
        after = {"status": ticket.status, "actual_priority": ticket.actual_priority, "assigned_to": ticket.assigned_to_id, "delivery_date": str(ticket.delivery_date) if ticket.delivery_date else None, "planned_hours": float(ticket.planned_hours) if ticket.planned_hours is not None else None}
        AuditLog.objects.create(ticket=ticket, actor=self.request.user, action="TICKET_UPDATED", before=before, after=after)

    def _manager_only(self, request):
        return request.user.is_superuser or request.user.role in {User.Roles.MANAGER, User.Roles.SUPERADMIN}

    def _agent_or_manager(self, request):
        return request.user.is_superuser or request.user.role in {User.Roles.INFRA_AGENT, User.Roles.MANAGER, User.Roles.SUPERADMIN}

    def _audit(self, ticket, action, before, after, actor):
        AuditLog.objects.create(ticket=ticket, actor=actor, action=action, before=before, after=after)

    @action(detail=True, methods=["post"])
    def review(self, request, pk=None):
        if not self._manager_only(request):
            return Response({"detail": "Manager access required."}, status=403)
        ticket = self.get_object()
        old = {"status": ticket.status, "actual_priority": ticket.actual_priority}
        for field in ["actual_priority", "delivery_date", "planned_start_date", "planned_hours", "assigned_to", "assigned_team"]:
            if field in request.data:
                setattr(ticket, field, request.data[field] or None)
        action_name = request.data.get("decision", "APPROVE")
        ticket.status = Ticket.Status.APPROVED if action_name == "APPROVE" else Ticket.Status.REJECTED if action_name == "REJECT" else Ticket.Status.NEEDS_INFORMATION
        ticket.save()
        self._audit(ticket, f"MANAGER_REVIEW_{action_name}", old, {"status": ticket.status, "actual_priority": ticket.actual_priority}, request.user)
        return Response(self.get_serializer(ticket).data)

    @action(detail=True, methods=["post"])
    def assign(self, request, pk=None):
        if not self._manager_only(request):
            return Response({"detail": "Manager access required."}, status=403)
        ticket = self.get_object()
        old = {"assigned_to": ticket.assigned_to_id, "assigned_team": ticket.assigned_team_id, "status": ticket.status}
        ticket.assigned_to_id = request.data.get("assigned_to") or None
        ticket.assigned_team_id = request.data.get("assigned_team") or None
        if not ticket.assigned_to_id and not ticket.assigned_team_id:
            return Response({"detail": "Provide assigned_to or assigned_team."}, status=400)
        ticket.status = Ticket.Status.ASSIGNED
        ticket.save()
        self._audit(ticket, "TICKET_ASSIGNED", old, {"assigned_to": ticket.assigned_to_id, "assigned_team": ticket.assigned_team_id, "status": ticket.status}, request.user)
        return Response(self.get_serializer(ticket).data)

    @action(detail=True, methods=["post"])
    def claim(self, request, pk=None):
        if not self._agent_or_manager(request):
            return Response({"detail": "Infrastructure agent access required."}, status=403)
        ticket = self.get_object()
        if ticket.assigned_to_id:
            return Response({"detail": "Ticket is already assigned."}, status=409)
        old = {"assigned_to": None, "status": ticket.status}
        ticket.assigned_to = request.user
        ticket.status = Ticket.Status.ASSIGNED
        ticket.save()
        self._audit(ticket, "TICKET_CLAIMED", old, {"assigned_to": request.user.id, "status": ticket.status}, request.user)
        return Response(self.get_serializer(ticket).data)

    @action(detail=True, methods=["post"])
    def transition(self, request, pk=None):
        ticket = self.get_object()
        new_status = request.data.get("status")
        allowed = {v for v, _ in Ticket.Status.choices}
        if new_status not in allowed:
            return Response({"detail": "Invalid status."}, status=400)
        if request.user.role == User.Roles.REQUESTER and new_status not in {Ticket.Status.CANCELLED}:
            return Response({"detail": "Requesters cannot perform this transition."}, status=403)
        old = {"status": ticket.status}
        ticket.status = new_status
        if new_status == Ticket.Status.CLOSED:
            ticket.closed_at = timezone.now()
        ticket.save()
        self._audit(ticket, "STATUS_CHANGED", old, {"status": new_status}, request.user)
        return Response(self.get_serializer(ticket).data)

    @action(detail=True, methods=["post"])
    def comment(self, request, pk=None):
        ticket = self.get_object()
        visibility = request.data.get("visibility", "PUBLIC")
        if visibility == "INTERNAL" and request.user.role == User.Roles.REQUESTER:
            return Response({"detail": "Requesters cannot add internal comments."}, status=403)
        ser = TicketCommentSerializer(data={"ticket": str(ticket.id), "body": request.data.get("body", ""), "visibility": visibility})
        ser.is_valid(raise_exception=True)
        comment = TicketComment.objects.create(ticket=ticket, author=request.user, body=ser.validated_data["body"], visibility=visibility)
        self._audit(ticket, "COMMENT_ADDED", {}, {"comment_id": comment.id, "visibility": visibility}, request.user)
        return Response(TicketCommentSerializer(comment).data, status=201)

class SubTaskViewSet(viewsets.ModelViewSet):
    queryset = SubTask.objects.select_related("ticket", "assignee", "created_by")
    serializer_class = SubTaskSerializer
    permission_classes = [RolePermission]
    filterset_fields = ["ticket", "assignee", "status", "priority"]
    search_fields = ["title", "description"]

    def perform_create(self, serializer):
        ticket_id = self.request.data.get("ticket")
        if self.request.user.role == User.Roles.REQUESTER:
            ticket = Ticket.objects.get(id=ticket_id)
            if ticket.requester_id != self.request.user.id:
                raise permissions.PermissionDenied("You can only create tasks for your own tickets.")
        serializer.save(created_by=self.request.user)

class CommentViewSet(viewsets.ModelViewSet):
    queryset = TicketComment.objects.select_related("ticket", "author")
    def get_queryset(self):
        qs = super().get_queryset()
        if self.request.user.role == User.Roles.REQUESTER and not self.request.user.is_superuser:
            qs = qs.filter(ticket__requester=self.request.user, visibility=TicketComment.Visibility.PUBLIC)
        return qs
    serializer_class = TicketCommentSerializer
    permission_classes = [RolePermission]
    filterset_fields = ["ticket", "visibility"]

    def perform_create(self, serializer):
        if serializer.validated_data.get("visibility") == TicketComment.Visibility.INTERNAL and self.request.user.role == User.Roles.REQUESTER:
            raise permissions.PermissionDenied("Requesters cannot create internal comments.")
        serializer.save(author=self.request.user)

class AttachmentViewSet(viewsets.ModelViewSet):
    queryset = Attachment.objects.select_related("ticket", "uploaded_by")
    serializer_class = AttachmentSerializer
    permission_classes = [RolePermission]
    parser_classes = [MultiPartParser, FormParser]
    filterset_fields = ["ticket"]

    def perform_create(self, serializer):
        ticket_id = self.request.data.get("ticket")
        ticket = Ticket.objects.get(id=ticket_id)
        if self.request.user.role == User.Roles.REQUESTER and ticket.requester_id != self.request.user.id:
            raise permissions.PermissionDenied("You can only attach files to your own tickets.")
        uploaded = self.request.FILES.get("file")
        name = uploaded.name if uploaded else ""
        if ticket.boq_document and not name.lower().endswith((".xlsx", ".xlsm")):
            # Other files are fine; this only blocks a non-Excel file where the BOQ field is explicitly selected for its first upload.
            pass
        serializer.save(uploaded_by=self.request.user, original_name=name, content_type=getattr(uploaded, "content_type", ""), size_bytes=getattr(uploaded, "size", 0))

class WorkLogViewSet(viewsets.ModelViewSet):
    queryset = WorkLog.objects.select_related("ticket", "user")
    serializer_class = WorkLogSerializer
    permission_classes = [RolePermission]
    filterset_fields = ["ticket", "user", "work_date"]

    def perform_create(self, serializer):
        log = serializer.save(user=self.request.user)
        total = WorkLog.objects.filter(ticket_id=log.ticket_id).aggregate(v=Sum("hours"))["v"] or Decimal("0")
        Ticket.objects.filter(id=log.ticket_id).update(actual_hours=total)

class ResourceAllocationViewSet(viewsets.ModelViewSet):
    queryset = ResourceAllocation.objects.select_related("user", "ticket", "allocated_by")
    def get_queryset(self):
        qs = super().get_queryset()
        if self.request.user.role == User.Roles.REQUESTER and not self.request.user.is_superuser:
            qs = qs.filter(user=self.request.user)
        return qs
    serializer_class = ResourceAllocationSerializer
    permission_classes = [RolePermission]
    filterset_fields = ["user", "ticket", "allocation_date"]

    def perform_create(self, serializer):
        if not (self.request.user.is_superuser or self.request.user.role in {User.Roles.MANAGER, User.Roles.SUPERADMIN}):
            raise permissions.PermissionDenied("Only managers can allocate capacity.")
        serializer.save(allocated_by=self.request.user)

class MeView(APIView):
    permission_classes = [RolePermission]
    def get(self, request):
        from .serializers import UserBriefSerializer
        return Response(UserBriefSerializer(request.user).data)

class DashboardView(APIView):
    permission_classes = [RolePermission]
    def get(self, request):
        qs = Ticket.objects.all()
        if request.user.role == User.Roles.REQUESTER and not request.user.is_superuser:
            qs = qs.filter(requester=request.user)
        today = timezone.localdate()
        week = today + timedelta(days=7)
        open_statuses = [Ticket.Status.CREATED, Ticket.Status.MANAGER_REVIEW, Ticket.Status.NEEDS_INFORMATION, Ticket.Status.APPROVED, Ticket.Status.ASSIGNED, Ticket.Status.IN_PROGRESS, Ticket.Status.ON_HOLD]
        total_open = qs.filter(status__in=open_statuses).count()
        awaiting_review = qs.filter(status=Ticket.Status.MANAGER_REVIEW).count()
        in_progress = qs.filter(status=Ticket.Status.IN_PROGRESS).count()
        overdue = qs.filter(delivery_date__lt=today, status__in=open_statuses).count()
        due_this_week = qs.filter(delivery_date__gte=today, delivery_date__lte=week, status__in=open_statuses).count()
        resolved = qs.filter(status=Ticket.Status.RESOLVED).count()
        planned = qs.aggregate(v=Sum("planned_hours"))["v"] or Decimal("0")
        actual = qs.aggregate(v=Sum("actual_hours"))["v"] or Decimal("0")
        team_utilisation = float(actual / planned * 100) if planned else 0
        return Response({
            "total_open": total_open, "awaiting_review": awaiting_review, "in_progress": in_progress,
            "overdue": overdue, "due_this_week": due_this_week, "resolved": resolved,
            "planned_hours": float(planned), "actual_hours": float(actual), "team_utilisation": round(team_utilisation, 1),
        })
