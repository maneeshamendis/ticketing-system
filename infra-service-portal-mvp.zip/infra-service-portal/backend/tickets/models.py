import os
import uuid
from datetime import date
from django.contrib.auth.models import AbstractUser
from django.core.exceptions import ValidationError
from django.db import models, transaction, IntegrityError


def attachment_upload_path(instance, filename):
    ext = os.path.splitext(filename)[1].lower()
    return f"tickets/{instance.ticket.ticket_number}/{uuid.uuid4()}{ext}"


class User(AbstractUser):
    class Roles(models.TextChoices):
        REQUESTER = "REQUESTER", "Requester"
        INFRA_AGENT = "INFRA_AGENT", "Infrastructure Agent"
        MANAGER = "MANAGER", "Manager"
        SUPERADMIN = "SUPERADMIN", "Superadmin"

    role = models.CharField(max_length=30, choices=Roles.choices, default=Roles.REQUESTER)
    department = models.CharField(max_length=120, blank=True)
    job_title = models.CharField(max_length=150, blank=True)
    ad_username = models.CharField(max_length=150, blank=True, unique=True, null=True)
    oidc_subject = models.CharField(max_length=255, blank=True, unique=True, null=True)
    is_ssm_managed = models.BooleanField(default=False, help_text="Reserved for AD/SSO lifecycle management.")

    def __str__(self):
        return self.get_full_name() or self.username


class Team(models.Model):
    name = models.CharField(max_length=120, unique=True)
    code = models.CharField(max_length=30, unique=True)
    description = models.TextField(blank=True)
    members = models.ManyToManyField(User, related_name="teams", blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class Category(models.Model):
    name = models.CharField(max_length=120, unique=True)
    code = models.CharField(max_length=30, unique=True)
    description = models.TextField(blank=True)
    default_sla_hours = models.PositiveIntegerField(default=40)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class TicketSequence(models.Model):
    year = models.PositiveIntegerField(unique=True)
    next_number = models.PositiveIntegerField(default=1)


class Ticket(models.Model):
    class TicketType(models.TextChoices):
        SERVICE_REQUEST = "SERVICE_REQUEST", "Service Request"
        INCIDENT = "INCIDENT", "Incident"
        CHANGE = "CHANGE", "Change"
        PROBLEM = "PROBLEM", "Problem"

    class Status(models.TextChoices):
        CREATED = "CREATED", "Created"
        MANAGER_REVIEW = "MANAGER_REVIEW", "Manager Review"
        NEEDS_INFORMATION = "NEEDS_INFORMATION", "Needs Information"
        APPROVED = "APPROVED", "Approved"
        ASSIGNED = "ASSIGNED", "Assigned"
        IN_PROGRESS = "IN_PROGRESS", "In Progress"
        ON_HOLD = "ON_HOLD", "On Hold"
        RESOLVED = "RESOLVED", "Resolved"
        CLOSED = "CLOSED", "Closed"
        REJECTED = "REJECTED", "Rejected"
        CANCELLED = "CANCELLED", "Cancelled"

    class Priority(models.TextChoices):
        P1 = "P1", "P1 - Critical"
        P2 = "P2", "P2 - High"
        P3 = "P3", "P3 - Medium"
        P4 = "P4", "P4 - Low"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    ticket_number = models.CharField(max_length=40, unique=True, editable=False)
    title = models.CharField(max_length=220)
    description = models.TextField()
    ticket_type = models.CharField(max_length=30, choices=TicketType.choices, default=TicketType.SERVICE_REQUEST)
    category = models.ForeignKey(Category, null=True, blank=True, on_delete=models.SET_NULL, related_name="tickets")
    requester = models.ForeignKey(User, on_delete=models.PROTECT, related_name="requested_tickets")
    assigned_to = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="assigned_tickets")
    assigned_team = models.ForeignKey(Team, null=True, blank=True, on_delete=models.SET_NULL, related_name="tickets")
    status = models.CharField(max_length=30, choices=Status.choices, default=Status.CREATED)
    requester_priority = models.CharField(max_length=2, choices=Priority.choices, default=Priority.P3)
    actual_priority = models.CharField(max_length=2, choices=Priority.choices, default=Priority.P3)
    is_bau = models.BooleanField(default=False)
    budget_approval = models.BooleanField(default=False)
    security_signoff = models.BooleanField(default=False)
    boq_document = models.BooleanField(default=False)
    pmo_hours_allocated = models.CharField(max_length=3, choices=[("YES", "Yes"), ("NO", "No"), ("N/A", "N/A")], default="N/A")
    requested_delivery_date = models.DateField(null=True, blank=True)
    planned_start_date = models.DateField(null=True, blank=True)
    delivery_date = models.DateField(null=True, blank=True)
    planned_hours = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    actual_hours = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    resolution = models.TextField(blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["status", "actual_priority"]),
            models.Index(fields=["assigned_to", "status"]),
            models.Index(fields=["delivery_date", "status"]),
        ]

    def save(self, *args, **kwargs):
        if not self.ticket_number:
            year = date.today().year
            with transaction.atomic():
                seq = TicketSequence.objects.select_for_update().filter(year=year).first()
                if seq is None:
                    try:
                        seq = TicketSequence.objects.create(year=year, next_number=2)
                        number = 1
                    except IntegrityError:
                        seq = TicketSequence.objects.select_for_update().get(year=year)
                        number = seq.next_number
                        seq.next_number += 1
                        seq.save(update_fields=["next_number"])
                else:
                    number = seq.next_number
                    seq.next_number += 1
                    seq.save(update_fields=["next_number"])
                self.ticket_number = f"INFRA-{year}-{number:06d}"
                super().save(*args, **kwargs)
                return
        super().save(*args, **kwargs)

    @property
    def days_left(self):
        if not self.delivery_date:
            return None
        return (self.delivery_date - date.today()).days

    def clean(self):
        if self.boq_document and self.boq_document is True:
            # The actual file requirement is validated at API layer because attachments are separate objects.
            pass
        if self.planned_hours is not None and self.planned_hours < 0:
            raise ValidationError("Planned hours cannot be negative.")

    def __str__(self):
        return f"{self.ticket_number} - {self.title}"


class TicketComment(models.Model):
    class Visibility(models.TextChoices):
        PUBLIC = "PUBLIC", "Public"
        INTERNAL = "INTERNAL", "Internal"

    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name="comments")
    author = models.ForeignKey(User, on_delete=models.PROTECT)
    body = models.TextField()
    visibility = models.CharField(max_length=10, choices=Visibility.choices, default=Visibility.PUBLIC)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]


class Attachment(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name="attachments")
    uploaded_by = models.ForeignKey(User, on_delete=models.PROTECT)
    file = models.FileField(upload_to=attachment_upload_path)
    original_name = models.CharField(max_length=255)
    content_type = models.CharField(max_length=120, blank=True)
    size_bytes = models.PositiveBigIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    def clean(self):
        allowed = {".xlsx", ".xlsm", ".pdf", ".docx", ".png", ".jpg", ".jpeg", ".txt", ".csv", ".zip"}
        ext = os.path.splitext(self.original_name or self.file.name)[1].lower()
        if ext not in allowed:
            raise ValidationError("Unsupported attachment type.")


class SubTask(models.Model):
    class Status(models.TextChoices):
        TODO = "TODO", "To Do"
        IN_PROGRESS = "IN_PROGRESS", "In Progress"
        BLOCKED = "BLOCKED", "Blocked"
        DONE = "DONE", "Done"

    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name="subtasks")
    title = models.CharField(max_length=220)
    description = models.TextField(blank=True)
    assignee = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="subtasks")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.TODO)
    priority = models.CharField(max_length=2, choices=Ticket.Priority.choices, default=Ticket.Priority.P3)
    due_date = models.DateField(null=True, blank=True)
    planned_hours = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    actual_hours = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    created_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name="created_subtasks")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class WorkLog(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name="worklogs")
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    work_date = models.DateField()
    hours = models.DecimalField(max_digits=6, decimal_places=2)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def clean(self):
        if self.hours <= 0:
            raise ValidationError("Hours must be greater than zero.")
        if self.hours > 24:
            raise ValidationError("A single work log cannot exceed 24 hours.")


class ResourceAllocation(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="resource_allocations")
    ticket = models.ForeignKey(Ticket, null=True, blank=True, on_delete=models.CASCADE, related_name="allocations")
    allocation_date = models.DateField()
    hours = models.DecimalField(max_digits=6, decimal_places=2)
    note = models.CharField(max_length=255, blank=True)
    allocated_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name="allocations_created")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["allocation_date", "user"]
        constraints = [
            models.CheckConstraint(condition=models.Q(hours__gte=0), name="allocation_hours_non_negative"),
        ]


class Approval(models.Model):
    class Kind(models.TextChoices):
        BUDGET = "BUDGET", "Budget"
        SECURITY = "SECURITY", "Security"
        PMO = "PMO", "PMO"
        MANAGER = "MANAGER", "Manager"
        CAB = "CAB", "CAB"

    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending"
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"

    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name="approvals")
    kind = models.CharField(max_length=20, choices=Kind.choices)
    requested_from = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="approval_requests")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    decision_note = models.TextField(blank=True)
    decided_at = models.DateTimeField(null=True, blank=True)


class AuditLog(models.Model):
    ticket = models.ForeignKey(Ticket, null=True, blank=True, on_delete=models.CASCADE, related_name="audit_logs")
    actor = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    action = models.CharField(max_length=100)
    before = models.JSONField(default=dict, blank=True)
    after = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
