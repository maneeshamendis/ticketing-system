import React, { useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import {
  Activity, AlertCircle, BarChart3, CalendarDays, CheckCircle2, ChevronRight, Clock3,
  FileText, Home, LogOut, Menu, Plus, Search, Settings2, ShieldCheck, Ticket as TicketIcon,
  Users, XCircle
} from 'lucide-react'
import './styles.css'

type User = { id:number; username:string; name:string; email:string; role:string; department:string }
type Category = { id:number; name:string; code:string; description:string; default_sla_hours:number; is_active:boolean }
type Ticket = {
  id:string; ticket_number:string; title:string; description:string; ticket_type:string; category:number|null;
  category_detail?:Category|null; requester:number; requester_detail:User; assigned_to:number|null; assigned_to_detail:User|null;
  status:string; requester_priority:string; actual_priority:string; is_bau:boolean; budget_approval:boolean; security_signoff:boolean;
  boq_document:boolean; pmo_hours_allocated:string; requested_delivery_date:string|null; planned_start_date:string|null;
  delivery_date:string|null; planned_hours:number|null; actual_hours:number; actual_hours_computed:number; days_left:number|null;
  created_at:string; updated_at:string; resolution:string; comments:any[]; attachments:any[]; subtasks:any[]; worklogs:any[]; audit_logs:any[];
}
type Dashboard = { total_open:number; awaiting_review:number; in_progress:number; overdue:number; due_this_week:number; resolved:number; planned_hours:number; actual_hours:number; team_utilisation:number }

const priorityLabel:Record<string,string> = { P1:'P1 · Critical', P2:'P2 · High', P3:'P3 · Medium', P4:'P4 · Low' }
const statusLabel:Record<string,string> = { CREATED:'Created', MANAGER_REVIEW:'Manager Review', NEEDS_INFORMATION:'Needs Information', APPROVED:'Approved', ASSIGNED:'Assigned', IN_PROGRESS:'In Progress', ON_HOLD:'On Hold', RESOLVED:'Resolved', CLOSED:'Closed', REJECTED:'Rejected', CANCELLED:'Cancelled' }

async function api(path:string, options:RequestInit={}) {
  const token = localStorage.getItem('access')
  const headers = new Headers(options.headers)
  if (options.body && !(options.body instanceof FormData)) headers.set('Content-Type','application/json')
  if (token) headers.set('Authorization', `Bearer ${token}`)
  const res = await fetch(path, {...options, headers})
  if (res.status === 401) { localStorage.removeItem('access'); localStorage.removeItem('refresh'); window.location.reload() }
  if (!res.ok) {
    let detail = `${res.status} ${res.statusText}`
    try { const data = await res.json(); detail = data.detail || JSON.stringify(data) } catch {}
    throw new Error(detail)
  }
  return res.status === 204 ? null : res.json()
}

function App() {
  const [me,setMe] = useState<User|null>(null)
  const [loginError,setLoginError] = useState('')
  const [loginBusy,setLoginBusy] = useState(false)
  useEffect(() => { if (localStorage.getItem('access')) api('/api/auth/me/').then(setMe).catch(()=>{}) }, [])

  async function login(username:string,password:string) {
    setLoginBusy(true); setLoginError('')
    try {
      const data = await fetch('/api/auth/token/', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({username,password})})
      if (!data.ok) throw new Error('Invalid username or password')
      const tokens = await data.json(); localStorage.setItem('access',tokens.access); localStorage.setItem('refresh',tokens.refresh)
      const user = await api('/api/auth/me/'); setMe(user)
    } catch(e:any) { setLoginError(e.message || 'Unable to sign in') }
    finally { setLoginBusy(false) }
  }
  if (!me) return <Login onLogin={login} error={loginError} busy={loginBusy}/>
  return <Portal user={me} onLogout={() => { localStorage.clear(); setMe(null) }}/>
}

function Login({onLogin,error,busy}:{onLogin:(u:string,p:string)=>void; error:string; busy:boolean}) {
  const [u,setU]=useState('admin'); const [p,setP]=useState('admin')
  return <div className="login-shell"><div className="login-card">
    <div className="brand-mark">IS</div><h1>Infrastructure Service Portal</h1><p className="muted">Internal IT service management</p>
    <label>Username<input value={u} onChange={e=>setU(e.target.value)} autoFocus/></label>
    <label>Password<input type="password" value={p} onChange={e=>setP(e.target.value)} onKeyDown={e=>e.key==='Enter'&&onLogin(u,p)}/></label>
    {error && <div className="alert error"><AlertCircle size={16}/>{error}</div>}
    <button className="primary full" disabled={busy} onClick={()=>onLogin(u,p)}>{busy?'Signing in…':'Sign in'}</button>
    <div className="login-note"><ShieldCheck size={16}/> AD / OIDC SSO is reserved for Phase 2.</div>
  </div></div>
}

function Portal({user,onLogout}:{user:User; onLogout:()=>void}) {
  const [view,setView] = useState('dashboard');
  const [selected,setSelected] = useState<string|null>(null)
  const [collapsed,setCollapsed] = useState(false)
  const manager = ['MANAGER','SUPERADMIN'].includes(user.role)
  const agent = ['INFRA_AGENT','MANAGER','SUPERADMIN'].includes(user.role)
  const nav = [
    ['dashboard','Dashboard',Home,true],
    ['tickets','Tickets',TicketIcon,true],
    ['new','New Request',Plus,true],
    ['planning','My Calendar',CalendarDays,true],
    ...(manager ? [['team','Team Planning',Users,true],['reports','Reports',BarChart3,true],['admin','Administration',Settings2,true]] : []),
  ] as any[]
  return <div className="app-shell">
    <aside className={collapsed?'sidebar collapsed':'sidebar'}>
      <div className="sidebar-head"><div className="brand-mark small">IS</div>{!collapsed&&<div><strong>Infra Portal</strong><span>Service Management</span></div>}<button className="icon-btn mobile-hide" onClick={()=>setCollapsed(!collapsed)}><Menu size={18}/></button></div>
      <nav>{nav.map(([id,label,Icon])=><button key={id} className={view===id?'nav-item active':'nav-item'} onClick={()=>{setView(id);setSelected(null)}}><Icon size={18}/>{!collapsed&&<span>{label}</span>}</button>)}</nav>
      <div className="sidebar-bottom">{!collapsed&&<div className="user-mini"><div className="avatar">{user.name.charAt(0).toUpperCase()}</div><div><strong>{user.name}</strong><span>{(user as any).role_display?.replace('_',' ') || user.role.replace('_',' ')}</span></div></div>}<button className="nav-item" onClick={onLogout}><LogOut size={18}/>{!collapsed&&<span>Sign out</span>}</button></div>
    </aside>
    <main className="main">
      {view==='dashboard' && <Dashboard user={user} onOpen={(id)=>{setSelected(id);setView('ticket')}}/>}
      {view==='tickets' && <TicketList user={user} onOpen={(id)=>{setSelected(id);setView('ticket')}} onNew={()=>{setView('new');setSelected(null)}}/>}
      {view==='new' && <NewRequest onCreated={(id)=>{setSelected(id);setView('ticket')}}/>}
      {view==='ticket' && selected && <TicketDetail id={selected} user={user} canWork={agent} canManage={manager}/>} 
      {view==='planning' && <Planning user={user} manager={false}/>} 
      {view==='team' && <Planning user={user} manager/>}
      {view==='reports' && <Reports/>}
      {view==='admin' && <Admin/>
      }
    </main>
  </div>
}

function PageHeader({eyebrow,title,action}:{eyebrow:string;title:string;action?:React.ReactNode}) { return <div className="page-header"><div><div className="eyebrow">{eyebrow}</div><h2>{title}</h2></div>{action}</div> }
function Metric({label,value,icon:Icon,sub}:{label:string;value:string|number;icon:any;sub?:string}) { return <div className="metric"><div className="metric-icon"><Icon size={18}/></div><div><div className="metric-label">{label}</div><div className="metric-value">{value}</div>{sub&&<div className="metric-sub">{sub}</div>}</div></div> }
function StatusPill({status}:{status:string}) { return <span className={`pill status-${status.toLowerCase()}`}>{statusLabel[status]||status}</span> }
function PriorityPill({priority}:{priority:string}) { return <span className={`pill priority-${priority.toLowerCase()}`}>{priorityLabel[priority]||priority}</span> }

function Dashboard({user,onOpen}:{user:User;onOpen:(id:string)=>void}) {
  const [d,setD]=useState<Dashboard|null>(null); const [tickets,setTickets]=useState<Ticket[]>([])
  useEffect(()=>{Promise.all([api('/api/dashboard/'),api('/api/tickets/?page_size=8')]).then(([a,b])=>{setD(a);setTickets(b.results)})},[])
  return <div className="page"><PageHeader eyebrow="Overview" title={`Good morning, ${user.name.split(' ')[0]}`} action={<button className="primary" onClick={()=>window.dispatchEvent(new CustomEvent('noop'))}>Operational View</button>}/>
    {d&&<div className="metric-grid">
      <Metric label="Open tickets" value={d.total_open} icon={TicketIcon} sub="Active workload"/>
      <Metric label="Awaiting review" value={d.awaiting_review} icon={Clock3} sub="Manager action"/>
      <Metric label="In progress" value={d.in_progress} icon={Activity} sub="Being delivered"/>
      <Metric label="Overdue" value={d.overdue} icon={AlertCircle} sub="Needs attention"/>
    </div>}
    <div className="two-col">
      <section className="card"><div className="section-head"><div><h3>Recent tickets</h3><p className="muted">Latest service requests and operational work</p></div></div>
      <div className="ticket-table">{tickets.map(t=><button className="ticket-row" key={t.id} onClick={()=>onOpen(t.id)}><div><strong>{t.ticket_number}</strong><span>{t.title}</span></div><PriorityPill priority={t.actual_priority}/><StatusPill status={t.status}/><div className={t.days_left!==null&&t.days_left<0?'due overdue':'due'}>{t.days_left===null?'—':t.days_left<0?`${Math.abs(t.days_left)}d overdue`:`${t.days_left}d left`}</div><ChevronRight size={16}/></button>)}</div></section>
      <section className="card"><div className="section-head"><div><h3>Delivery pulse</h3><p className="muted">Planned vs actual effort</p></div></div>
        {d&&<><div className="big-number">{Math.round(d.team_utilisation)}<span>%</span></div><div className="muted">Actual hours against planned hours</div><div className="progress"><div style={{width:`${Math.min(d.team_utilisation,100)}%`}}/></div><div className="stat-line"><span>Planned</span><strong>{d.planned_hours}h</strong></div><div className="stat-line"><span>Actual</span><strong>{d.actual_hours}h</strong></div><div className="stat-line"><span>Due this week</span><strong>{d.due_this_week}</strong></div></>}
      </section>
    </div>
  </div>
}

function TicketList({user,onOpen,onNew}:{user:User;onOpen:(id:string)=>void;onNew:()=>void}) {
  const [rows,setRows]=useState<Ticket[]>([]); const [q,setQ]=useState(''); const [status,setStatus]=useState(''); const [priority,setPriority]=useState('')
  async function load(){const params=new URLSearchParams({page_size:'50'});if(q)params.set('search',q);if(status)params.set('status',status);if(priority)params.set('actual_priority',priority);const data=await api(`/api/tickets/?${params}`);setRows(data.results)}
  useEffect(()=>{load()},[status,priority])
  return <div className="page"><PageHeader eyebrow="Work queue" title="Tickets" action={<button className="primary" onClick={onNew}><Plus size={17}/>New request</button>}/>
    <div className="toolbar card"><div className="search"><Search size={17}/><input placeholder="Search ticket, title or description" value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==='Enter'&&load()}/></div><select value={status} onChange={e=>setStatus(e.target.value)}><option value="">All statuses</option>{Object.entries(statusLabel).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select><select value={priority} onChange={e=>setPriority(e.target.value)}><option value="">All priorities</option>{Object.entries(priorityLabel).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></div>
    <section className="card"><div className="ticket-table table-header"><div>Ticket</div><div>Priority</div><div>Status</div><div>Delivery</div><div/></div>{rows.map(t=><button className="ticket-row table" key={t.id} onClick={()=>onOpen(t.id)}><div><strong>{t.ticket_number}</strong><span>{t.title}</span></div><PriorityPill priority={t.actual_priority}/><StatusPill status={t.status}/><div className={t.days_left!==null&&t.days_left<0?'due overdue':'due'}>{t.delivery_date||'Not planned'}{t.days_left!==null&&<small>{t.days_left<0?` · ${Math.abs(t.days_left)}d overdue`:` · ${t.days_left}d left`}</small>}</div><ChevronRight size={16}/></button>)}</section>
  </div>
}

function NewRequest({onCreated}:{onCreated:(id:string)=>void}) {
  const [cats,setCats]=useState<Category[]>([]); const [busy,setBusy]=useState(false); const [error,setError]=useState('')
  const [f,setF]=useState<any>({title:'',description:'',ticket_type:'SERVICE_REQUEST',category:'',requester_priority:'P3',requested_delivery_date:'',is_bau:false,budget_approval:false,security_signoff:false,boq_document:false,pmo_hours_allocated:'N/A'})
  const [file,setFile]=useState<File|null>(null)
  useEffect(()=>{api('/api/categories/?page_size=100').then(d=>setCats(d.results))},[])
  const set=(k:string,v:any)=>setF((x:any)=>({...x,[k]:v}))
  async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setError('');try{
    if(f.boq_document && !file) throw new Error('Please attach the BOQ Excel file when BOQ Document is selected.')
    if(file && !/\.(xlsx|xlsm)$/i.test(file.name)) throw new Error('BOQ document must be an Excel .xlsx or .xlsm file.')
    const payload={...f,category:f.category?Number(f.category):null,requested_delivery_date:f.requested_delivery_date||null}
    const t=await api('/api/tickets/',{method:'POST',body:JSON.stringify(payload)})
    if(file){const form=new FormData();form.append('ticket',t.id);form.append('file',file);await api('/api/attachments/',{method:'POST',body:form})}
    onCreated(t.id)
  }catch(e:any){setError(e.message)}finally{setBusy(false)}}
  return <div className="page"><PageHeader eyebrow="Service catalogue" title="New infrastructure request"/>
    <form className="card form-card" onSubmit={submit}>
      {error&&<div className="alert error"><AlertCircle size={16}/>{error}</div>}
      <div className="form-grid"><label className="span-2">Request title<input required value={f.title} onChange={e=>set('title',e.target.value)} placeholder="e.g. Create production Linux server"/></label>
      <label>Request type<select value={f.ticket_type} onChange={e=>set('ticket_type',e.target.value)}><option value="SERVICE_REQUEST">Service Request</option><option value="INCIDENT">Incident</option><option value="CHANGE">Change</option><option value="PROBLEM">Problem</option></select></label>
      <label>Category<select value={f.category} onChange={e=>set('category',e.target.value)}><option value="">Select category</option>{cats.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
      <label className="span-2">Description<textarea required rows={5} value={f.description} onChange={e=>set('description',e.target.value)} placeholder="Describe the requirement, business context and expected outcome…"/></label>
      <label>Requested delivery date<input type="date" value={f.requested_delivery_date} onChange={e=>set('requested_delivery_date',e.target.value)}/></label>
      <label>Suggested priority<select value={f.requester_priority} onChange={e=>set('requester_priority',e.target.value)}>{Object.entries(priorityLabel).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></label>
      <div className="span-2 subsection"><h4>Governance & prerequisites</h4><div className="checks">{[['budget_approval','Budget approval'],['security_signoff','Security sign-off'],['boq_document','BOQ document'],['is_bau','BAU requirement']].map(([k,l])=><label className="check" key={k}><input type="checkbox" checked={!!f[k]} onChange={e=>set(k,e.target.checked)}/><span>{l}</span></label>)}</div></div>
      <label>PMO hours allocated<select value={f.pmo_hours_allocated} onChange={e=>set('pmo_hours_allocated',e.target.value)}><option value="YES">Yes</option><option value="NO">No</option><option value="N/A">N/A</option></select></label>
      <label>BOQ Excel upload<input type="file" accept=".xlsx,.xlsm" onChange={e=>setFile(e.target.files?.[0]||null)} disabled={!f.boq_document}/>{f.boq_document&&<small className="muted">Required when BOQ Document is selected.</small>}</label>
      </div>
      <div className="form-footer"><div className="muted">Your priority is a suggestion. The Infrastructure manager assigns the actual priority after review.</div><button className="primary" disabled={busy}>{busy?'Submitting…':'Submit request'}</button></div>
    </form>
  </div>
}

function TicketDetail({id,user,canWork,canManage}:{id:string;user:User;canWork:boolean;canManage:boolean}) {
  const [t,setT]=useState<Ticket|null>(null); const [users,setUsers]=useState<User[]>([]); const [comment,setComment]=useState(''); const [subtask,setSubtask]=useState(''); const [work,setWork]=useState(''); const [message,setMessage]=useState('')
  async function load(){const data=await api(`/api/tickets/${id}/`);setT(data)}
  useEffect(()=>{load(); if(canManage) api('/api/users/?page_size=100').then(d=>setUsers(d.results))},[id])
  if(!t) return <div className="page"><div className="loading">Loading ticket…</div></div>
  const ticket = t
  const canClaim=canWork&&!ticket.assigned_to
  async function transition(status:string){await api(`/api/tickets/${id}/transition/`,{method:'POST',body:JSON.stringify({status})});load()}
  async function claim(){await api(`/api/tickets/${id}/claim/`,{method:'POST'});load()}
  async function addComment(){if(!comment.trim())return;await api(`/api/tickets/${id}/comment/`,{method:'POST',body:JSON.stringify({body:comment,visibility:'PUBLIC'})});setComment('');load()}
  async function addInternal(){if(!comment.trim())return;await api(`/api/tickets/${id}/comment/`,{method:'POST',body:JSON.stringify({body:comment,visibility:'INTERNAL'})});setComment('');load()}
  async function createSubtask(){if(!subtask.trim())return;await api('/api/subtasks/',{method:'POST',body:JSON.stringify({ticket:id,title:subtask,status:'TODO',priority:ticket.actual_priority})});setSubtask('');load()}
  async function logWork(){const hours=Number(work);if(!hours)return;await api('/api/worklogs/',{method:'POST',body:JSON.stringify({ticket:id,work_date:new Date().toISOString().slice(0,10),hours,description:'Work logged from portal'})});setWork('');load()}
  async function review(decision:string){
    const actual=(document.getElementById('manager-priority') as HTMLSelectElement)?.value || ticket.actual_priority
    const delivery=(document.getElementById('manager-delivery') as HTMLInputElement)?.value || ticket.delivery_date || ''
    const hours=(document.getElementById('manager-hours') as HTMLInputElement)?.value || ticket.planned_hours || ''
    await api(`/api/tickets/${id}/review/`,{method:'POST',body:JSON.stringify({decision,actual_priority:actual,delivery_date:delivery||null,planned_hours:hours||null})});load()
  }
  return <div className="page">
    <PageHeader eyebrow={t.ticket_number} title={t.title} action={<div className="header-actions">{canClaim&&<button className="secondary" onClick={claim}>Claim ticket</button>}{canWork&&t.status==='ASSIGNED'&&<button className="primary" onClick={()=>transition('IN_PROGRESS')}>Start work</button>}{canWork&&t.status==='IN_PROGRESS'&&<button className="secondary" onClick={()=>transition('RESOLVED')}>Resolve</button>}</div>}/>
    {message&&<div className="alert success"><CheckCircle2 size={16}/>{message}</div>}
    <div className="ticket-detail-grid">
      <div className="left-stack">
        <section className="card"><div className="ticket-title-line"><div><div className="ticket-num">{t.ticket_number}</div><h3>{t.title}</h3></div><div><PriorityPill priority={t.actual_priority}/><StatusPill status={t.status}/></div></div><div className="description">{t.description}</div>
          <div className="detail-meta"><div><span>Requester priority</span><strong><PriorityPill priority={t.requester_priority}/></strong></div><div><span>Actual priority</span><strong><PriorityPill priority={t.actual_priority}/></strong></div><div><span>Assignee</span><strong>{t.assigned_to_detail?.name||'Unassigned'}</strong></div><div><span>Delivery date</span><strong>{t.delivery_date||'Not planned'}</strong></div><div><span>Planned hours</span><strong>{t.planned_hours??'—'}h</strong></div><div><span>Actual hours</span><strong>{t.actual_hours_computed}h</strong></div></div>
        </section>
        {canManage && t.status==='MANAGER_REVIEW' && <section className="card manager-review"><div className="section-head"><div><h3>Manager review</h3><p className="muted">Set the actual priority, delivery commitment and workload before approval.</p></div><span className="pill status-manager_review">Awaiting decision</span></div><div className="form-grid"><label>Actual priority<select id="manager-priority" defaultValue={t.actual_priority}>{Object.entries(priorityLabel).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></label><label>Delivery date<input id="manager-delivery" type="date" defaultValue={t.delivery_date||t.requested_delivery_date||''}/></label><label>Planned hours<input id="manager-hours" type="number" min="0" step="0.25" defaultValue={t.planned_hours||''}/></label></div><div className="form-footer"><button className="secondary" onClick={()=>review('NEEDS_INFORMATION')}>Need information</button><button className="danger" onClick={()=>review('REJECT')}>Reject</button><button className="primary" onClick={()=>review('APPROVE')}>Approve & plan</button></div></section>}
        {canManage && <section className="card"><div className="section-head"><div><h3>Assignment</h3><p className="muted">Assign the ticket to an infrastructure resource or leave it available for pickup.</p></div></div><div className="form-grid"><label>Resource<select id="assign-user" defaultValue={t.assigned_to||''}><option value="">Unassigned / team pickup</option>{users.map(u=><option key={u.id} value={u.id}>{u.name} · {u.role.replace('_',' ')}</option>)}</select></label></div><div className="form-footer"><button className="secondary" onClick={async()=>{const v=(document.getElementById('assign-user') as HTMLSelectElement).value; if(!v)return; await api(`/api/tickets/${id}/assign/`,{method:'POST',body:JSON.stringify({assigned_to:Number(v)})});load()}}>Assign resource</button></div></section>}
        <section className="card"><div className="section-head"><div><h3>Activity</h3><p className="muted">Comments, decisions and audit history</p></div></div><div className="timeline">{t.comments.map((c:any)=><div className="timeline-item" key={`c${c.id}`}><div className="avatar small">{c.author_detail.name.charAt(0)}</div><div><div><strong>{c.author_detail.name}</strong><span className="muted"> · {new Date(c.created_at).toLocaleString()}</span></div><p>{c.body}</p>{c.visibility==='INTERNAL'&&<span className="pill internal">Internal</span>}</div></div>)}{t.audit_logs.slice(0,8).map((a:any)=><div className="timeline-item audit" key={`a${a.id}`}><div className="audit-dot"><Activity size={13}/></div><div><strong>{a.action.replaceAll('_',' ')}</strong><span className="muted"> · {new Date(a.created_at).toLocaleString()}</span></div></div>)}</div><div className="comment-box"><textarea value={comment} onChange={e=>setComment(e.target.value)} placeholder="Write a comment…" rows={3}/><div><button className="secondary" onClick={addComment}>Add comment</button>{canWork&&<button className="ghost" onClick={addInternal}>Internal note</button>}</div></div></section>
      </div>
      <div className="right-stack">
        <section className="card"><h3>Delivery</h3><div className={`days-left ${t.days_left!==null&&t.days_left<0?'overdue':''}`}>{t.days_left===null?'—':t.days_left<0?`${Math.abs(t.days_left)} days overdue`:`${t.days_left} days left`}</div><div className="stat-line"><span>Target</span><strong>{t.delivery_date||'Not planned'}</strong></div><div className="stat-line"><span>Planned</span><strong>{t.planned_hours??0}h</strong></div><div className="stat-line"><span>Actual</span><strong>{t.actual_hours_computed}h</strong></div></section>
        <section className="card"><div className="section-head"><div><h3>Subtasks</h3><p className="muted">{t.subtasks.filter((s:any)=>s.status==='DONE').length} / {t.subtasks.length} complete</p></div></div>{t.subtasks.map((s:any)=><div className="subtask" key={s.id}><div><strong>{s.title}</strong><span>{s.assignee_detail?.name||'Unassigned'} · {s.due_date||'No due date'}</span></div><StatusPill status={s.status}/></div>)}{canWork&&<div className="inline-add"><input value={subtask} onChange={e=>setSubtask(e.target.value)} placeholder="New subtask"/><button className="secondary" onClick={createSubtask}><Plus size={16}/></button></div>}</section>
        {canWork&&<section className="card"><h3>Log work</h3><div className="inline-add"><input value={work} onChange={e=>setWork(e.target.value)} type="number" min="0.25" step="0.25" placeholder="Hours"/><button className="primary" onClick={logWork}>Log</button></div></section>}
        <section className="card"><h3>Attachments</h3>{t.attachments.length===0?<div className="empty"><FileText size={18}/>No attachments</div>:t.attachments.map((a:any)=><a className="attachment" key={a.id} href={a.file} target="_blank"><FileText size={17}/><span>{a.original_name}</span></a>)}</section>
        <section className="card"><h3>Governance</h3><div className="governance"><div><span>Budget approval</span><strong>{t.budget_approval?'YES':'NO'}</strong></div><div><span>Security sign-off</span><strong>{t.security_signoff?'YES':'NO'}</strong></div><div><span>BOQ document</span><strong>{t.boq_document?'YES':'NO'}</strong></div><div><span>PMO hours</span><strong>{t.pmo_hours_allocated}</strong></div><div><span>BAU</span><strong>{t.is_bau?'YES':'NO'}</strong></div></div></section>
      </div>
    </div>
  </div>
}

function Planning({user,manager}:{user:User;manager:boolean}) {
  const [alloc,setAlloc]=useState<any[]>([]); const [users,setUsers]=useState<User[]>([])
  const [weekStart,setWeekStart]=useState(()=>{const d=new Date();const day=(d.getDay()+6)%7;d.setDate(d.getDate()-day);return d.toISOString().slice(0,10)})
  const [newAlloc,setNewAlloc]=useState({user:'',date:weekStart,hours:'',ticket:'',note:''}); const [allocBusy,setAllocBusy]=useState(false)
  const days=Array.from({length:7},(_,i)=>{const d=new Date(`${weekStart}T00:00:00`);d.setDate(d.getDate()+i);return {date:d.toISOString().slice(0,10),label:d.toLocaleDateString(undefined,{weekday:'short',day:'2-digit'})}})
  async function load(){const qs=days.map(d=>api(`/api/allocations/?allocation_date=${d.date}&page_size=200${manager?'':`&user=${user.id}`}`));const arr=await Promise.all(qs);setAlloc(arr.flatMap(x=>x.results))}
  useEffect(()=>{load();if(manager)api('/api/users/?page_size=100').then(d=>setUsers(d.results))},[weekStart,manager])
  const byDay=(date:string)=>alloc.filter(a=>a.allocation_date===date)
  async function createAllocation(){if(!newAlloc.user||!newAlloc.hours||!newAlloc.date)return;setAllocBusy(true);try{await api('/api/allocations/',{method:'POST',body:JSON.stringify({user:Number(newAlloc.user),allocation_date:newAlloc.date,hours:Number(newAlloc.hours),ticket:newAlloc.ticket||null,note:newAlloc.note})});setNewAlloc(x=>({...x,hours:'',ticket:'',note:''}));await load()}finally{setAllocBusy(false)}}
  return <div className="page"><PageHeader eyebrow={manager?'Capacity management':'Personal capacity'} title={manager?'Team planning':'My calendar'} action={<input className="date-pick" type="date" value={weekStart} onChange={e=>setWeekStart(e.target.value)}/>}/>
    {manager&&<section className="card allocation-form"><div className="section-head"><div><h3>Add capacity allocation</h3><p className="muted">Allocate hours against a person and optional ticket. Drag-and-drop planning can be added in Phase 2.</p></div></div><div className="form-grid"><label>Resource<select value={newAlloc.user} onChange={e=>setNewAlloc(x=>({...x,user:e.target.value}))}><option value="">Select person</option>{users.filter(u=>['INFRA_AGENT','MANAGER','SUPERADMIN'].includes(u.role)).map(u=><option key={u.id} value={u.id}>{u.name}</option>)}</select></label><label>Date<input type="date" value={newAlloc.date} min={days[0].date} max={days[6].date} onChange={e=>setNewAlloc(x=>({...x,date:e.target.value}))}/></label><label>Hours<input type="number" min="0.25" step="0.25" value={newAlloc.hours} onChange={e=>setNewAlloc(x=>({...x,hours:e.target.value}))}/></label><label>Ticket number (optional)<input value={newAlloc.ticket} onChange={e=>setNewAlloc(x=>({...x,ticket:e.target.value}))} placeholder="UUID for now"/></label><label className="span-2">Note<input value={newAlloc.note} onChange={e=>setNewAlloc(x=>({...x,note:e.target.value}))} placeholder="Patch window, project work, operational duty…"/></label></div><div className="form-footer"><span className="muted">Week: {weekStart} → {days[6].date}</span><button className="primary" disabled={allocBusy} onClick={createAllocation}>Add allocation</button></div></section>}
    <section className="card"><div className="calendar-grid">{days.map(day=><div className="day-column" key={day.date}><div className="day-header"><strong>{day.label}</strong><span>{byDay(day.date).reduce((s:number,a:any)=>s+Number(a.hours),0)}h</span></div>{byDay(day.date).length===0?<div className="day-empty">No work</div>:byDay(day.date).map(a=><div className="allocation" key={a.id}><span>{a.ticket_number||'Capacity'}</span><small>{a.user_detail?.name||user.name} · {a.hours}h</small><small>{a.note}</small></div>)}</div>)}</div></section>
  </div>
}

function Reports(){const [d,setD]=useState<Dashboard|null>(null);useEffect(()=>{api('/api/dashboard/').then(setD)},[]);return <div className="page"><PageHeader eyebrow="Management reporting" title="Operational reports"/><div className="metric-grid">{d&&<><Metric label="Open backlog" value={d.total_open} icon={TicketIcon}/><Metric label="Overdue" value={d.overdue} icon={AlertCircle}/><Metric label="Due this week" value={d.due_this_week} icon={CalendarDays}/><Metric label="Utilisation" value={`${Math.round(d.team_utilisation)}%`} icon={BarChart3}/></>}</div><div className="two-col"><section className="card"><h3>Report catalogue</h3>{['Open tickets','Overdue tickets','SLA compliance (Phase 2)','Backlog aging','Planned vs actual hours','Engineer utilisation','BAU vs project','Priority distribution'].map(x=><div className="report-link" key={x}><BarChart3 size={16}/><span>{x}</span><ChevronRight size={16}/></div>)}</section><section className="card"><h3>Planned vs actual</h3>{d&&<><div className="chart-bars"><div><span>Planned</span><div className="bar"><i style={{width:'100%'}}/></div><strong>{d.planned_hours}h</strong></div><div><span>Actual</span><div className="bar"><i style={{width:`${d.planned_hours?Math.min(d.actual_hours/d.planned_hours*100,100):0}%`}}/></div><strong>{d.actual_hours}h</strong></div></div></>}</section></div></div>}

function Admin(){return <div className="page"><PageHeader eyebrow="Administration" title="Platform administration"/><section className="card"><div className="admin-grid"><div><ShieldCheck/><h3>Identity & access</h3><p>Users are modelled with Requester, Infra Agent, Manager and Superadmin roles. OIDC/AD fields are already present for the Phase 2 SSO integration.</p></div><div><Users/><h3>User management</h3><p>Use Django admin to manage users, teams, categories and controlled configuration until the full admin GUI is added.</p><a href="/admin/" target="_blank">Open Django admin →</a></div><div><Settings2/><h3>Operational configuration</h3><p>SLA policies, service catalogue, approvals and automation are designed as separate modules for Phase 2.</p></div></div></section></div>}

createRoot(document.getElementById('root')!).render(<React.StrictMode><App/></React.StrictMode>)
