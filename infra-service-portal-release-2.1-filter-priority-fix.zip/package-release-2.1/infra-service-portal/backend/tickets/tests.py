from datetime import date, timedelta

from rest_framework.test import APITestCase, APIClient

from .models import Team, Ticket, User


class TicketWorkflowRegressionTests(APITestCase):
    def setUp(self):
        self.manager = User.objects.create_user(
            username="manager-test",
            password="test-password",
            first_name="Test",
            last_name="Manager",
            role=User.Roles.MANAGER,
        )
        self.requester = User.objects.create_user(
            username="requester-test",
            password="test-password",
            first_name="Test",
            last_name="Requester",
            role=User.Roles.REQUESTER,
        )
        self.team = Team.objects.create(name="Infrastructure", code="INFRA")
        self.team.members.add(self.manager)
        self.client = APIClient()
        self.client.force_authenticate(self.manager)

    def create_ticket(self):
        return Ticket.objects.create(
            title="Regression test ticket",
            description="Regression test",
            requester=self.requester,
            assigned_team=self.team,
            requester_priority=Ticket.Priority.P3,
            actual_priority=Ticket.Priority.P3,
            status=Ticket.Status.CREATED,
        )

    def test_needs_review_queue_includes_new_and_returned_tickets(self):
        created = self.create_ticket()
        review = self.create_ticket()
        review.status = Ticket.Status.MANAGER_REVIEW
        review.save(update_fields=["status", "updated_at"])
        needs_info = self.create_ticket()
        needs_info.status = Ticket.Status.NEEDS_INFORMATION
        needs_info.save(update_fields=["status", "updated_at"])
        approved = self.create_ticket()
        approved.status = Ticket.Status.APPROVED
        approved.save(update_fields=["status", "updated_at"])

        response = self.client.get("/api/tickets/?queue=NEEDS_REVIEW&page_size=100")
        self.assertEqual(response.status_code, 200)
        returned_ids = {row["id"] for row in response.data["results"]}
        self.assertEqual(returned_ids, {str(created.id), str(review.id), str(needs_info.id)})
        self.assertNotIn(str(approved.id), returned_ids)

    def test_save_review_persists_manager_priority_change_and_visibility(self):
        ticket = self.create_ticket()
        ticket.status = Ticket.Status.MANAGER_REVIEW
        ticket.save(update_fields=["status", "updated_at"])

        response = self.client.post(
            f"/api/tickets/{ticket.id}/save_review/",
            {
                "actual_priority": Ticket.Priority.P1,
                "delivery_date": (date.today() + timedelta(days=5)).isoformat(),
                "planned_hours": 8,
                "assigned_team": self.team.id,
                "note": "Priority changed after manager review.",
                "note_visible_to_requester": True,
            },
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        ticket.refresh_from_db()
        self.assertEqual(ticket.actual_priority, Ticket.Priority.P1)
        self.assertTrue(ticket.manager_review_note_visible)
        self.assertEqual(ticket.manager_review_note, "Priority changed after manager review.")
        self.assertIsNotNone(ticket.manager_reviewed_at)

    def test_final_review_persists_priority_and_moves_ticket_forward(self):
        ticket = self.create_ticket()
        ticket.status = Ticket.Status.MANAGER_REVIEW
        ticket.save(update_fields=["status", "updated_at"])

        response = self.client.post(
            f"/api/tickets/{ticket.id}/review/",
            {
                "decision": "APPROVE",
                "actual_priority": Ticket.Priority.P2,
                "delivery_date": (date.today() + timedelta(days=5)).isoformat(),
                "planned_hours": 6,
                "assigned_to": self.manager.id,
                "assigned_team": self.team.id,
                "note": "Approved with High priority.",
                "note_visible_to_requester": True,
            },
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        ticket.refresh_from_db()
        self.assertEqual(ticket.actual_priority, Ticket.Priority.P2)
        self.assertEqual(ticket.status, Ticket.Status.ASSIGNED)
