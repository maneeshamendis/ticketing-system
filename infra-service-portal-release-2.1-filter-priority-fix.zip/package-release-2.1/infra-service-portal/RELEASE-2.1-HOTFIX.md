# Release 2.1 Hotfix

## Fixes

### Ticket queues
- `Needs review` is now a virtual queue containing `CREATED`, `MANAGER_REVIEW`, and `NEEDS_INFORMATION` tickets.
- The exact status filters continue to work independently.
- The frontend now surfaces ticket-list API errors instead of silently showing an empty queue.

### Manager priority/review updates
- Added `Save review changes` while a ticket is in `MANAGER_REVIEW`.
- Manager priority changes are persisted immediately and recorded in the audit trail.
- Manager review comments can be explicitly marked requester-visible.
- `NEEDS_INFORMATION` comments are always requester-visible.
- Review date/hours values are validated and normalized before saving.
- Duplicate identical review comments are avoided when a saved review is subsequently approved.

## Database

No schema migration is required for this hotfix.

## Deployment

Rebuild `api`, `worker`, `beat`, and `frontend` images. Do not remove the PostgreSQL volume.
