from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from tickets.api import (
    UserViewSet, TeamViewSet, CategoryViewSet, TicketViewSet, CapacityView,
    SubTaskViewSet, CommentViewSet, AttachmentViewSet,
    WorkLogViewSet, ResourceAllocationViewSet, DashboardView, MeView,
)

router = DefaultRouter()
router.register("users", UserViewSet, basename="user")
router.register("teams", TeamViewSet, basename="team")
router.register("categories", CategoryViewSet, basename="category")
router.register("tickets", TicketViewSet, basename="ticket")
router.register("subtasks", SubTaskViewSet, basename="subtask")
router.register("comments", CommentViewSet, basename="comment")
router.register("attachments", AttachmentViewSet, basename="attachment")
router.register("worklogs", WorkLogViewSet, basename="worklog")
router.register("allocations", ResourceAllocationViewSet, basename="allocation")

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/auth/token/", TokenObtainPairView.as_view(), name="token_obtain_pair"),
    path("api/auth/token/refresh/", TokenRefreshView.as_view(), name="token_refresh"),
    path("api/dashboard/", DashboardView.as_view(), name="dashboard"),
    path("api/capacity/", CapacityView.as_view(), name="capacity"),
    path("api/auth/me/", MeView.as_view(), name="me"),
    path("api/", include(router.urls)),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
