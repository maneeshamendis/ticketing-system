from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from .models import User, Team, Category, Ticket, TicketSequence, TicketComment, Attachment, SubTask, WorkLog, ResourceAllocation, Approval, AuditLog

@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    fieldsets = DjangoUserAdmin.fieldsets + (("Portal", {"fields": ("role", "department", "job_title", "ad_username", "oidc_subject", "is_ssm_managed", "weekly_capacity_hours")} ),)
    list_display = ("username", "email", "role", "is_active", "department")
    search_fields = ("username", "email", "first_name", "last_name", "ad_username")

@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = ("ticket_number", "title", "status", "actual_priority", "requester", "assigned_to", "delivery_date")
    list_filter = ("status", "actual_priority", "ticket_type", "is_bau")
    search_fields = ("ticket_number", "title", "description")
    readonly_fields = ("ticket_number", "created_at", "updated_at", "manager_reviewed_at")

@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    filter_horizontal = ("members",)

for model in [Category, TicketSequence, TicketComment, Attachment, SubTask, WorkLog, ResourceAllocation, Approval, AuditLog]:
    admin.site.register(model)
