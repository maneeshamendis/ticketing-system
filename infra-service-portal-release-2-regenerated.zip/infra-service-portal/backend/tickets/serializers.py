from django.contrib.auth import get_user_model
from django.db.models import Sum
from rest_framework import serializers
from .models import Team, Category, Ticket, TicketComment, Attachment, SubTask, WorkLog, ResourceAllocation, Approval, AuditLog

User = get_user_model()

class UserBriefSerializer(serializers.ModelSerializer):
    name = serializers.SerializerMethodField()
    role_display = serializers.SerializerMethodField()
    class Meta:
        model = User
        fields = ("id", "username", "name", "email", "role", "role_display", "department")
    def get_name(self, obj):
        return obj.get_full_name() or obj.username
    def get_role_display(self, obj):
        return User.Roles.SUPERADMIN if obj.is_superuser else obj.role

class UserSerializer(UserBriefSerializer):
    class Meta(UserBriefSerializer.Meta):
        fields = UserBriefSerializer.Meta.fields + ("job_title", "ad_username", "oidc_subject", "is_ssm_managed", "weekly_capacity_hours", "is_active")

class TeamSerializer(serializers.ModelSerializer):
    members_detail = UserBriefSerializer(source="members", many=True, read_only=True)
    class Meta:
        model = Team
        fields = ("id", "name", "code", "description", "members", "members_detail", "is_active")

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = "__all__"

class TicketCommentSerializer(serializers.ModelSerializer):
    author_detail = UserBriefSerializer(source="author", read_only=True)
    class Meta:
        model = TicketComment
        fields = ("id", "ticket", "author", "author_detail", "body", "visibility", "created_at")
        read_only_fields = ("author",)

class AttachmentSerializer(serializers.ModelSerializer):
    uploaded_by_detail = UserBriefSerializer(source="uploaded_by", read_only=True)
    class Meta:
        model = Attachment
        fields = ("id", "ticket", "file", "original_name", "content_type", "size_bytes", "uploaded_by_detail", "created_at")
        read_only_fields = ("uploaded_by", "original_name", "content_type", "size_bytes")

class SubTaskSerializer(serializers.ModelSerializer):
    assignee_detail = UserBriefSerializer(source="assignee", read_only=True)
    created_by_detail = UserBriefSerializer(source="created_by", read_only=True)
    class Meta:
        model = SubTask
        fields = "__all__"
        read_only_fields = ("created_by",)

class WorkLogSerializer(serializers.ModelSerializer):
    user_detail = UserBriefSerializer(source="user", read_only=True)
    class Meta:
        model = WorkLog
        fields = "__all__"
        read_only_fields = ("user",)

class ResourceAllocationSerializer(serializers.ModelSerializer):
    user_detail = UserBriefSerializer(source="user", read_only=True)
    ticket_number = serializers.CharField(source="ticket.ticket_number", read_only=True)
    subtask_title = serializers.CharField(source="subtask.title", read_only=True)
    allocated_by_detail = UserBriefSerializer(source="allocated_by", read_only=True)
    class Meta:
        model = ResourceAllocation
        fields = "__all__"
        read_only_fields = ("allocated_by", "ticket_number", "subtask_title", "allocated_by_detail")

    def validate(self, attrs):
        ticket = attrs.get("ticket")
        subtask = attrs.get("subtask")
        if subtask and ticket and subtask.ticket_id != ticket.id:
            raise serializers.ValidationError({"subtask": "The selected subtask does not belong to the selected ticket."})
        return attrs

class ApprovalSerializer(serializers.ModelSerializer):
    requested_from_detail = UserBriefSerializer(source="requested_from", read_only=True)
    class Meta:
        model = Approval
        fields = "__all__"

class AuditLogSerializer(serializers.ModelSerializer):
    actor_detail = UserBriefSerializer(source="actor", read_only=True)
    class Meta:
        model = AuditLog
        fields = "__all__"

class TicketSerializer(serializers.ModelSerializer):
    requester_detail = UserBriefSerializer(source="requester", read_only=True)
    assigned_to_detail = UserBriefSerializer(source="assigned_to", read_only=True)
    assigned_team_detail = TeamSerializer(source="assigned_team", read_only=True)
    category_detail = CategorySerializer(source="category", read_only=True)
    comments = serializers.SerializerMethodField()
    attachments = AttachmentSerializer(many=True, read_only=True)
    subtasks = SubTaskSerializer(many=True, read_only=True)
    worklogs = WorkLogSerializer(many=True, read_only=True)
    approvals = ApprovalSerializer(many=True, read_only=True)
    audit_logs = AuditLogSerializer(many=True, read_only=True)
    days_left = serializers.IntegerField(read_only=True)
    actual_hours_computed = serializers.SerializerMethodField()
    allocated_hours = serializers.SerializerMethodField()
    unallocated_hours = serializers.SerializerMethodField()
    priority_changed = serializers.SerializerMethodField()
    manager_review_note = serializers.SerializerMethodField()
    manager_reviewed_by_detail = UserBriefSerializer(source="manager_reviewed_by", read_only=True)

    class Meta:
        model = Ticket
        fields = [
            "id", "ticket_number", "title", "description", "ticket_type", "category", "category_detail",
            "requester", "requester_detail", "assigned_to", "assigned_to_detail", "assigned_team", "assigned_team_detail",
            "status", "requester_priority", "actual_priority", "is_bau", "budget_approval", "security_signoff",
            "boq_document", "pmo_hours_allocated", "requested_delivery_date", "planned_start_date", "delivery_date",
            "planned_hours", "actual_hours", "actual_hours_computed", "allocated_hours", "unallocated_hours", "resolution",
            "manager_review_note", "manager_review_note_visible", "manager_reviewed_by", "manager_reviewed_by_detail", "manager_reviewed_at",
            "priority_changed", "closed_at", "created_at", "updated_at",
            "days_left", "comments", "attachments", "subtasks", "worklogs", "approvals", "audit_logs",
        ]
        read_only_fields = ("requester", "ticket_number", "actual_hours", "closed_at", "manager_reviewed_by", "manager_reviewed_at")

    def get_comments(self, obj):
        request = self.context.get("request")
        comments = obj.comments.all()
        if request and request.user.role == User.Roles.REQUESTER and not request.user.is_superuser:
            comments = comments.filter(visibility=TicketComment.Visibility.PUBLIC)
        return TicketCommentSerializer(comments, many=True, context=self.context).data

    def get_actual_hours_computed(self, obj):
        total = obj.worklogs.aggregate(v=Sum("hours"))["v"] or 0
        return float(total)

    def get_allocated_hours(self, obj):
        total = obj.allocations.aggregate(v=Sum("hours"))["v"] or 0
        return float(total)

    def get_unallocated_hours(self, obj):
        if obj.planned_hours is None:
            return None
        allocated = obj.allocations.aggregate(v=Sum("hours"))["v"] or 0
        return max(float(obj.planned_hours) - float(allocated), 0)

    def get_priority_changed(self, obj):
        return bool(obj.manager_reviewed_at and obj.requester_priority != obj.actual_priority)

    def get_manager_review_note(self, obj):
        request = self.context.get("request")
        if request and request.user.role == User.Roles.REQUESTER and not request.user.is_superuser:
            return obj.manager_review_note if obj.manager_review_note_visible else ""
        return obj.manager_review_note

class DashboardSerializer(serializers.Serializer):
    total_open = serializers.IntegerField()
    awaiting_review = serializers.IntegerField()
    in_progress = serializers.IntegerField()
    overdue = serializers.IntegerField()
    due_this_week = serializers.IntegerField()
    resolved = serializers.IntegerField()
    planned_hours = serializers.FloatField()
    actual_hours = serializers.FloatField()
    team_utilisation = serializers.FloatField()
