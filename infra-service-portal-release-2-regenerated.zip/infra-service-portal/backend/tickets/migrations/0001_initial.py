# Generated for the Infra Service Management Portal MVP.
from django.conf import settings
from django.db import migrations, models
import django.contrib.auth.models
import django.contrib.auth.validators
import django.db.models.deletion
import django.utils.timezone
import os
import tickets.models
import uuid


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        ("auth", "0012_alter_user_first_name_max_length"),
    ]

    operations = [
        migrations.CreateModel(
            name="Category",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=120, unique=True)),
                ("code", models.CharField(max_length=30, unique=True)),
                ("description", models.TextField(blank=True)),
                ("default_sla_hours", models.PositiveIntegerField(default=40)),
                ("is_active", models.BooleanField(default=True)),
            ],
        ),
        migrations.CreateModel(
            name="Team",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=120, unique=True)),
                ("code", models.CharField(max_length=30, unique=True)),
                ("description", models.TextField(blank=True)),
                ("is_active", models.BooleanField(default=True)),
            ],
        ),
        migrations.CreateModel(
            name="TicketSequence",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("year", models.PositiveIntegerField(unique=True)),
                ("next_number", models.PositiveIntegerField(default=1)),
            ],
        ),
        migrations.CreateModel(
            name="User",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("password", models.CharField(max_length=128, verbose_name="password")),
                ("last_login", models.DateTimeField(blank=True, null=True, verbose_name="last login")),
                ("is_superuser", models.BooleanField(default=False, help_text="Designates that this user has all permissions without explicitly assigning them.", verbose_name="superuser status")),
                ("username", models.CharField(error_messages={"unique": "A user with that username already exists."}, help_text="Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.", max_length=150, unique=True, validators=[django.contrib.auth.validators.UnicodeUsernameValidator()], verbose_name="username")),
                ("first_name", models.CharField(blank=True, max_length=150, verbose_name="first name")),
                ("last_name", models.CharField(blank=True, max_length=150, verbose_name="last name")),
                ("email", models.EmailField(blank=True, max_length=254, verbose_name="email address")),
                ("is_staff", models.BooleanField(default=False, help_text="Designates whether the user can log into this admin site.", verbose_name="staff status")),
                ("is_active", models.BooleanField(default=True, help_text="Designates whether this user should be treated as active. Unselect this instead of deleting accounts.", verbose_name="active")),
                ("date_joined", models.DateTimeField(default=django.utils.timezone.now, verbose_name="date joined")),
                ("role", models.CharField(choices=[("REQUESTER", "Requester"), ("INFRA_AGENT", "Infrastructure Agent"), ("MANAGER", "Manager"), ("SUPERADMIN", "Superadmin")], default="REQUESTER", max_length=30)),
                ("department", models.CharField(blank=True, max_length=120)),
                ("job_title", models.CharField(blank=True, max_length=150)),
                ("ad_username", models.CharField(blank=True, max_length=150, null=True, unique=True)),
                ("oidc_subject", models.CharField(blank=True, max_length=255, null=True, unique=True)),
                ("is_ssm_managed", models.BooleanField(default=False, help_text="Reserved for AD/SSO lifecycle management.")),
                ("groups", models.ManyToManyField(blank=True, help_text="The groups this user belongs to. A user will get all permissions granted to each of their groups.", related_name="user_set", related_query_name="user", to="auth.group", verbose_name="groups")),
                ("user_permissions", models.ManyToManyField(blank=True, help_text="Specific permissions for this user.", related_name="user_set", related_query_name="user", to="auth.permission", verbose_name="user permissions")),
            ],
            options={
                "verbose_name": "user",
                "verbose_name_plural": "users",
                "abstract": False,
            },
            managers=[
                ("objects", django.contrib.auth.models.UserManager()),
            ],
        ),
        migrations.AddField(
            model_name="team",
            name="members",
            field=models.ManyToManyField(blank=True, related_name="teams", to="tickets.user"),
        ),
        migrations.CreateModel(
            name="Ticket",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("ticket_number", models.CharField(editable=False, max_length=40, unique=True)),
                ("title", models.CharField(max_length=220)),
                ("description", models.TextField()),
                ("ticket_type", models.CharField(choices=[("SERVICE_REQUEST", "Service Request"), ("INCIDENT", "Incident"), ("CHANGE", "Change"), ("PROBLEM", "Problem")], default="SERVICE_REQUEST", max_length=30)),
                ("status", models.CharField(choices=[("CREATED", "Created"), ("MANAGER_REVIEW", "Manager Review"), ("NEEDS_INFORMATION", "Needs Information"), ("APPROVED", "Approved"), ("ASSIGNED", "Assigned"), ("IN_PROGRESS", "In Progress"), ("ON_HOLD", "On Hold"), ("RESOLVED", "Resolved"), ("CLOSED", "Closed"), ("REJECTED", "Rejected"), ("CANCELLED", "Cancelled")], default="CREATED", max_length=30)),
                ("requester_priority", models.CharField(choices=[("P1", "P1 - Critical"), ("P2", "P2 - High"), ("P3", "P3 - Medium"), ("P4", "P4 - Low")], default="P3", max_length=2)),
                ("actual_priority", models.CharField(choices=[("P1", "P1 - Critical"), ("P2", "P2 - High"), ("P3", "P3 - Medium"), ("P4", "P4 - Low")], default="P3", max_length=2)),
                ("is_bau", models.BooleanField(default=False)),
                ("budget_approval", models.BooleanField(default=False)),
                ("security_signoff", models.BooleanField(default=False)),
                ("boq_document", models.BooleanField(default=False)),
                ("pmo_hours_allocated", models.CharField(choices=[("YES", "Yes"), ("NO", "No"), ("N/A", "N/A")], default="N/A", max_length=3)),
                ("requested_delivery_date", models.DateField(blank=True, null=True)),
                ("planned_start_date", models.DateField(blank=True, null=True)),
                ("delivery_date", models.DateField(blank=True, null=True)),
                ("planned_hours", models.DecimalField(blank=True, decimal_places=2, max_digits=8, null=True)),
                ("actual_hours", models.DecimalField(decimal_places=2, default=0, max_digits=8)),
                ("resolution", models.TextField(blank=True)),
                ("closed_at", models.DateTimeField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("assigned_team", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="tickets", to="tickets.team")),
                ("assigned_to", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="assigned_tickets", to="tickets.user")),
                ("category", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="tickets", to="tickets.category")),
                ("requester", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="requested_tickets", to="tickets.user")),
            ],
            options={
                "ordering": ["-created_at"],
                "indexes": [
                    models.Index(fields=["status", "actual_priority"], name="tickets_tic_status_4d6b9e_idx"),
                    models.Index(fields=["assigned_to", "status"], name="tickets_tic_assigned_69b5c1_idx"),
                    models.Index(fields=["delivery_date", "status"], name="tickets_tic_delivery_5a9438_idx"),
                ],
            },
        ),
        migrations.CreateModel(
            name="Attachment",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("file", models.FileField(upload_to=tickets.models.attachment_upload_path)),
                ("original_name", models.CharField(max_length=255)),
                ("content_type", models.CharField(blank=True, max_length=120)),
                ("size_bytes", models.PositiveBigIntegerField(default=0)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("ticket", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="attachments", to="tickets.ticket")),
                ("uploaded_by", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to="tickets.user")),
            ],
        ),
        migrations.CreateModel(
            name="SubTask",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("title", models.CharField(max_length=220)),
                ("description", models.TextField(blank=True)),
                ("status", models.CharField(choices=[("TODO", "To Do"), ("IN_PROGRESS", "In Progress"), ("BLOCKED", "Blocked"), ("DONE", "Done")], default="TODO", max_length=20)),
                ("priority", models.CharField(choices=[("P1", "P1 - Critical"), ("P2", "P2 - High"), ("P3", "P3 - Medium"), ("P4", "P4 - Low")], default="P3", max_length=2)),
                ("due_date", models.DateField(blank=True, null=True)),
                ("planned_hours", models.DecimalField(blank=True, decimal_places=2, max_digits=8, null=True)),
                ("actual_hours", models.DecimalField(decimal_places=2, default=0, max_digits=8)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("assignee", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="subtasks", to="tickets.user")),
                ("created_by", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="created_subtasks", to="tickets.user")),
                ("ticket", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="subtasks", to="tickets.ticket")),
            ],
        ),
        migrations.CreateModel(
            name="TicketComment",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("body", models.TextField()),
                ("visibility", models.CharField(choices=[("PUBLIC", "Public"), ("INTERNAL", "Internal")], default="PUBLIC", max_length=10)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("author", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to="tickets.user")),
                ("ticket", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="comments", to="tickets.ticket")),
            ],
            options={"ordering": ["created_at"]},
        ),
        migrations.CreateModel(
            name="WorkLog",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("work_date", models.DateField()),
                ("hours", models.DecimalField(decimal_places=2, max_digits=6)),
                ("description", models.TextField(blank=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("ticket", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="worklogs", to="tickets.ticket")),
                ("user", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to="tickets.user")),
            ],
        ),
        migrations.CreateModel(
            name="ResourceAllocation",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("allocation_date", models.DateField()),
                ("hours", models.DecimalField(decimal_places=2, max_digits=6)),
                ("note", models.CharField(blank=True, max_length=255)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("ticket", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name="allocations", to="tickets.ticket")),
                ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="resource_allocations", to="tickets.user")),
                ("allocated_by", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="allocations_created", to="tickets.user")),
            ],
            options={
                "ordering": ["allocation_date", "user"],
                "constraints": [models.CheckConstraint(condition=models.Q(("hours__gte", 0)), name="allocation_hours_non_negative")],
            },
        ),
        migrations.CreateModel(
            name="Approval",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("kind", models.CharField(choices=[("BUDGET", "Budget"), ("SECURITY", "Security"), ("PMO", "PMO"), ("MANAGER", "Manager"), ("CAB", "CAB")], max_length=20)),
                ("status", models.CharField(choices=[("PENDING", "Pending"), ("APPROVED", "Approved"), ("REJECTED", "Rejected")], default="PENDING", max_length=20)),
                ("decision_note", models.TextField(blank=True)),
                ("decided_at", models.DateTimeField(blank=True, null=True)),
                ("requested_from", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="approval_requests", to="tickets.user")),
                ("ticket", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="approvals", to="tickets.ticket")),
            ],
        ),
        migrations.CreateModel(
            name="AuditLog",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("action", models.CharField(max_length=100)),
                ("before", models.JSONField(blank=True, default=dict)),
                ("after", models.JSONField(blank=True, default=dict)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("actor", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to="tickets.user")),
                ("ticket", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name="audit_logs", to="tickets.ticket")),
            ],
            options={"ordering": ["-created_at"]},
        ),
    ]
