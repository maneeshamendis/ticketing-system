from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [("tickets", "0001_initial")]

    operations = [
        migrations.AddField(
            model_name="user", name="weekly_capacity_hours",
            field=models.DecimalField(decimal_places=2, default=40, help_text="Planned working capacity per week for resource planning.", max_digits=6),
        ),
        migrations.AddField(
            model_name="ticket", name="manager_review_note",
            field=models.TextField(blank=True),
        ),
        migrations.AddField(
            model_name="ticket", name="manager_review_note_visible",
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name="ticket", name="manager_reviewed_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="ticket", name="manager_reviewed_by",
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="manager_reviews", to="tickets.user"),
        ),
        migrations.AddField(
            model_name="resourceallocation", name="subtask",
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name="allocations", to="tickets.subtask"),
        ),
    ]
