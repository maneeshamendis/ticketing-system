from celery import shared_task
from django.utils import timezone
from .models import Ticket

@shared_task
def scan_overdue_tickets():
    today = timezone.localdate()
    qs = Ticket.objects.filter(
        delivery_date__lt=today,
        status__in=[
            Ticket.Status.CREATED, Ticket.Status.MANAGER_REVIEW, Ticket.Status.NEEDS_INFORMATION,
            Ticket.Status.APPROVED, Ticket.Status.ASSIGNED, Ticket.Status.IN_PROGRESS, Ticket.Status.ON_HOLD,
        ],
    )
    return qs.count()
