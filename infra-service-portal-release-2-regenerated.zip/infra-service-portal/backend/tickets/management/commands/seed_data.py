from django.core.management.base import BaseCommand
from tickets.models import User, Team, Category

class Command(BaseCommand):
    help = "Seed the initial Infrastructure portal categories, team and optional development admin."

    def add_arguments(self, parser):
        parser.add_argument('--demo-user', action='store_true', help='Create/reset local demo accounts admin/admin and engineer/engineer.')

    def handle(self, *args, **opts):
        categories = [
            ('Cloud Infrastructure', 'CLOUD', 16),
            ('Linux / RHEL', 'LINUX', 16),
            ('Windows', 'WINDOWS', 16),
            ('Networking', 'NETWORK', 8),
            ('Database', 'DATABASE', 16),
            ('Kubernetes / Containers', 'K8S', 8),
            ('Middleware', 'MIDDLEWARE', 16),
            ('Security', 'SECURITY', 8),
        ]
        for name, code, sla in categories:
            Category.objects.update_or_create(code=code, defaults={'name': name, 'default_sla_hours': sla, 'is_active': True})
        team, _ = Team.objects.get_or_create(code='INFRA', defaults={'name':'Infrastructure Team', 'description':'Core Infrastructure and Cloud operations.'})
        self.stdout.write(self.style.SUCCESS('Base categories and Infrastructure Team are ready.'))
        if opts['demo_user']:
            admin, created = User.objects.get_or_create(username='admin', defaults={'email':'admin@example.local','first_name':'Portal','last_name':'Admin','role':User.Roles.SUPERADMIN, 'is_superuser':True, 'is_staff':True})
            admin.set_password('admin'); admin.is_superuser=True; admin.is_staff=True; admin.role=User.Roles.SUPERADMIN; admin.save()
            engineer, _ = User.objects.get_or_create(username='engineer', defaults={'email':'engineer@example.local','first_name':'Infra','last_name':'Engineer','role':User.Roles.INFRA_AGENT})
            engineer.set_password('engineer'); engineer.role=User.Roles.INFRA_AGENT; engineer.save()
            team.members.add(engineer)
            self.stdout.write(self.style.WARNING('Demo accounts created: admin/admin and engineer/engineer. Change these before any real deployment.'))
