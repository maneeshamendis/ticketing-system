# Release 2 — Resource & Capacity Management

This release adds team capacity planning and requester-visible manager review outcomes.

## Included
- Weekly resource calendar for managers and personal calendar for users.
- Weekly capacity per user (default 40h).
- Daily allocations linked to tickets or subtasks.
- Capacity, allocated, available and utilisation metrics.
- Over-capacity warnings.
- Ticket planned vs allocated hours.
- Manager allocation create/delete and capacity editing.
- Manager-controlled review comment visibility to requester.
- Requester-visible priority change highlight after manager review.
- Internal vs requester-visible manager review note handling.
- NEEDS INFORMATION requires a requester-visible manager note.

## Migration
Normal Django migrations are used. Do not reset the database volume.
