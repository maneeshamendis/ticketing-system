#!/usr/bin/env sh
set -eu
WEB_PORT="${WEB_HOST_PORT:-18080}"
API_PORT="${API_HOST_PORT:-18081}"
printf 'Checking host ports %s and %s...\n' "$WEB_PORT" "$API_PORT"
for p in "$WEB_PORT" "$API_PORT"; do
  if command -v ss >/dev/null 2>&1; then
    if ss -ltn | awk '{print $4}' | grep -qE ":${p}$"; then echo "Port $p is already in use."; exit 1; fi
  elif command -v lsof >/dev/null 2>&1; then
    if lsof -nP -iTCP:"$p" -sTCP:LISTEN >/dev/null 2>&1; then echo "Port $p is already in use."; exit 1; fi
  else
    echo "Neither ss nor lsof is available; skipping socket check."
    break
  fi
done
echo 'Required host ports are available.'
